export type ItemName =
  | 'potion'
  | 'rare-candy'
  | 'running-shoes'
  | 'super-potion'
  | 'x-attack'
  | 'exp-share'
  | 'hyper-potion'
  | 'escape-rope';