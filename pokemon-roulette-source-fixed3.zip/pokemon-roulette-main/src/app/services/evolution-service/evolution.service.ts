import { Injectable } from '@angular/core';
import { PokemonItem } from '../../interfaces/pokemon-item';
import { evolutionChain } from './evolution-chain';
import { PokemonService } from '../pokemon-service/pokemon.service';

@Injectable({
  providedIn: 'root'
})
export class EvolutionService {

  evolutionChain = evolutionChain;

  constructor(private pokemonService: PokemonService) {}

  /**
   * Hisui forms are allowed as evolution targets even when the base Pokémon is not regional
   * (because Hisui is not a selectable region in this game).
   *
   * Project convention: Hisuian forms use PokeAPI "form" IDs in the 10229..10247 range.
   */
  private isHisuianFormId(id: number): boolean {
    return id >= 10229 && id <= 10247;
  }

  /**
   * Some Pokémon are present in evolutionChain as an empty list (e.g., 211: []).
   * In JS/TS, [] is truthy, which used to make the UI think it could evolve and then freeze.
   */
  canEvolve(pokemon: PokemonItem): boolean {
    return this.getEvolutions(pokemon).length > 0;
  }

  /**
   * Rules (as requested):
   * - Regional base Pokémon (has basePokemonId): evolves only to its regional evolution(s)
   *   (prefers regional form evolutions when both base + form are present in the chain).
   * - Original (non-regional) Pokémon: does NOT evolve into regional forms,
   *   EXCEPT:
   *     - Hisui forms are allowed (Hisuian Typhlosion etc.)
   *     - Pikachu (25) is allowed to evolve into Alolan Raichu (10100).
   */
  getEvolutions(pokemon: PokemonItem): PokemonItem[] {
    const chain = this.evolutionChain[pokemon.pokemonId];
    if (!chain || chain.length === 0) return [];

    const evolutions: PokemonItem[] = chain
      .map((id) => this.pokemonService.getPokemonById(id))
      .filter((p): p is PokemonItem => !!p);

    // ✅ Special case: Pikachu can evolve to both Raichu (26) and Alolan Raichu (10100)
    if (pokemon.pokemonId === 25) {
      return evolutions;
    }

    // 🔴 If the base Pokémon is a regional form, keep its regional line.
    // Additionally, if the chain contains BOTH the base species evolution (e.g., Persian 53)
    // and a regional form of that evolution (e.g., Persian-Alola with basePokemonId 53),
    // we remove the base species evolution and keep the form.
    if (pokemon.basePokemonId) {
      const formBaseIds = new Set<number>(
        evolutions.filter(e => !!e.basePokemonId).map(e => e.basePokemonId as number)
      );
      return evolutions.filter(e => !formBaseIds.has(e.pokemonId));
    }

    // 🔵 Non-regional base: block regional-form evolutions, allow Hisui forms.
    return evolutions.filter(e => !e.basePokemonId || this.isHisuianFormId(e.pokemonId));
  }
}
