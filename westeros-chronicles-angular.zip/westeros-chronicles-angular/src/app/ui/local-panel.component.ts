import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GameState, Character } from '../core/models';

@Component({
  selector: 'app-local-panel',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './local-panel.component.html',
  styleUrl: './local-panel.component.css',
})
export class LocalPanelComponent {
  @Input({ required: true }) state!: GameState;
  @Output() choose = new EventEmitter<string>();

  get player(): Character {
    return this.state.characters[this.state.playerId];
  }

  charsHere(): Character[] {
    const here = this.player.locationId;
    return Object.values(this.state.characters)
      .filter(c => c.alive && c.id !== this.player.id && c.locationId === here)
      .sort((a,b)=> (b.relationshipToPlayer ?? 0) - (a.relationshipToPlayer ?? 0))
      .slice(0, 40);
  }

  houseName(houseId: string): string {
    return this.state.houses[houseId]?.name ?? houseId;
  }

  on(action: 'talk'|'flowers'|'drink'|'hunt', targetId: string): void {
    this.choose.emit(`loc:${action}:${targetId}`);
  }
}
