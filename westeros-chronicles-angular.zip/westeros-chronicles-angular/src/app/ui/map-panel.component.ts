import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GameState } from '../core/models';

@Component({
  selector: 'app-map-panel',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './map-panel.component.html',
  styleUrl: './map-panel.component.css',
})
export class MapPanelComponent {
  @Input({ required: true }) state!: GameState;
  @Output() choose = new EventEmitter<string>();

  travelOptions(): Array<{label: string, id: string, hint: string}> {
    const p = this.state.characters[this.state.playerId];
    const here = this.state.locations[p.locationId];
    const edges = this.state.travelGraph[here.id] ?? [];
    return edges.map(e => {
      const to = this.state.locations[e.toLocationId];
      return {
        label: to.name,
        id: `go:${to.id}`,
        hint: `Distância ${e.distance}`,
      };
    });
  }

  onGo(id: string): void {
    this.choose.emit(id);
  }
}
