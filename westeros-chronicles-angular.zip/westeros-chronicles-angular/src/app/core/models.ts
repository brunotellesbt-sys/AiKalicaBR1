export type Gender = 'M' | 'F';

export type RelationshipKind = 'hostil' | 'neutro' | 'amigavel' | 'aliado' | 'aliança';

export interface GameDate {
  year: number;          // "Depois da Conquista" (DC)
  turn: number;          // 1..20  (1 turno = 1/20 de ano)
  absoluteTurn: number;  // contador global
}

export interface Resources {
  gold: number;
  food: number;
}

export type UnitTier = 'levies' | 'menAtArms' | 'squires' | 'knights';

export interface Army {
  levies: number;
  menAtArms: number;
  squires: number;
  knights: number;
  /**
   * Dragões não são uma mecânica "jogável" no protótipo.
   * Quando presentes (ex.: Daenerys), contam como equivalentes a 10.000 cavaleiros por dragão.
   */
  dragons: number;
  stationedRatio: number; // 0..1 (parte que fica na cidade)
}

export interface HouseEconomy {
  peasants: number;
  soldiers: number; // cidadãos armados (base)
  farms: number;
  trainingGrounds: number;
  walls: number;
  tradeLastDelegationTurn: number;
  tradePartners: string[];
}

export interface HouseDef {
  id: string;
  name: string;
  regionId: string;
  seatLocationId: string;
  prestigeBase: number;
  suzerainId?: string; // casa suserana imediata (geralmente a Grande Casa da região)
  isIronThrone?: boolean;
}

export interface HouseState extends HouseDef {
  prestige: number;          // 1..100
  relations: Record<string, number>; // 0..100 (com outras casas)
  leaderId: string;
  economy: HouseEconomy;
  resources: Resources;
  army: Army;
}

export type Fertility = 'fertile' | 'sterile';

export type MaritalStatus = 'single' | 'married' | 'widowed';

export interface Character {
  id: string;
  name: string;
  gender: Gender;
  ageYears: number;
  alive: boolean;

  birthHouseId: string;
  currentHouseId: string;

  fatherId?: string;
  motherId?: string;
  spouseId?: string;
  maritalStatus: MaritalStatus;
  keepsBirthName: boolean; // usado principalmente para mulheres líderes que decidem manter o sobrenome

  locationId: string;

  // Progressão e atributos
  martial: number;   // 0..100
  charm: number;     // 0..100
  beauty: number;    // 0..100  (homens: aparência + renome; mulheres: apresentação/roupas)
  renownTier: RenownTier;

  fertility: Fertility;
  wellLiked: number; // 0..100 (ser \"bem quisto\" em geral)

  // Prestígio pessoal (separado do prestígio da Casa)
  personalPrestige: number; // 0..100

  // ferimentos (ex.: torneios). Se definido, penaliza ações até este turno
  injuredUntilTurn?: number;

  // relações pessoais com o jogador
  knownToPlayer: boolean;
  relationshipToPlayer: number; // 0..100

  title?: string;
}

export type RenownTier = 'comum' | 'forte' | 'reconhecido' | 'imponente' | 'renomado';

export interface Location {
  id: string;
  name: string;
  regionId: string;
  kind: 'seat' | 'town' | 'fortress' | 'port';
}

export interface Region {
  id: string;
  name: string;
  capitalLocationId: string;
}

export interface TravelOption {
  toLocationId: string;
  distance: number;      // abstrato
}

export interface ChronicleEntry {
  turn: number;
  title: string;
  body: string;
  tags: string[];
}


export type TournamentSize = 'menor' | 'medio' | 'importante';

export type TournamentReason = 'maioridade' | 'casamento' | 'vitoria' | 'colheita' | 'outro';

export interface Tournament {
  id: string;
  hostHouseId: string;
  locationId: string;
  size: TournamentSize;
  reason: TournamentReason;
  announcedTurn: number;
  status: 'anunciado' | 'encerrado';
  categories: RenownTier[];
}


export type Speaker = 'sistema' | 'narrador' | 'npc';

export interface Choice {
  id: string;
  label: string;
  hint?: string;
  disabled?: boolean;
}

export interface ChatMessage {
  id: string;
  speaker: Speaker;
  title?: string;
  text: string;
  tsTurn: number;
  choices?: Choice[];
  chosenId?: string;
}

export interface GameState {
  version: number;
  date: GameDate;

  game: {
    over: boolean;
    victory: boolean;
    reason: string;
  };

  endgame: {
    wallBreached: boolean;
    danyArrived: boolean;
    danyHouseId?: string;
    danyLeaderId?: string;
    danyRelation: number; // relação pessoal com Daenerys (0..100)
    kingsLandingBurned: boolean;
  };

  playerId: string;
  playerHouseId: string;

  locations: Record<string, Location>;
  regions: Record<string, Region>;
  travelGraph: Record<string, TravelOption[]>;

  houses: Record<string, HouseState>;
  characters: Record<string, Character>;

  tournaments: Tournament[];

  chronicle: ChronicleEntry[];
  chat: ChatMessage[];

  // Sistema de empréstimo com o Banco de Ferro
  ironBankDebt: {
    principal: number;
    interestRateYear: number; // ex: 0.12 = 12% a.a.
    nextPaymentTurn: number;
    minimumPayment: number;
    missedPayments: number;
  } | null;

  // UI
  ui: {
    activeTab: 'chat' | 'map' | 'local' | 'tournaments' | 'character' | 'house' | 'diplomacy' | 'chronicle' | 'saves';
    showSetup: boolean;
    pendingNameQueue?: string[]; // ids de bebês do jogador aguardando nome
  };
}
