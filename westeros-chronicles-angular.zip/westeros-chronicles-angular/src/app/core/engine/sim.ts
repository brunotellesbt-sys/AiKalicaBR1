import {
  Army,
  Character,
  Choice,
  ChronicleEntry,
  GameState,
  Gender,
  HouseState,
  Location,
  RenownTier,
  Tournament,
  TournamentReason,
  TournamentSize,
} from '../models';
import { Rng } from './rng';
import { clamp, uid } from './utils';
import { genFirstName, maybeEpithet } from './names';
import { SCHEDULED_EVENTS } from '../data/timeline';

export interface NewGameParams {
  playerHouseId: string;
  gender: Gender;
}

const RENOWN_ORDER: RenownTier[] = ['comum', 'forte', 'reconhecido', 'imponente', 'renomado'];

// --- Endgame (Gelo & Fogo) ---
// Por padrão, usamos a convenção popular de datas: eventos do fim da série em 304–305 DC.
// (Brecha na Muralha ~ 304; queda/incêndio de Porto Real ~ 305.)
const ENDGAME_WALL_YEAR = 304;
const ENDGAME_WALL_TURN = 20;
const ENDGAME_DANY_YEAR = 305;
const ENDGAME_DANY_TURN = 2;
const ENDGAME_BURN_YEAR = 305;
const ENDGAME_BURN_TURN = 12;

const DANY_HOUSE_ID = 'targaryen_dany';

export function renownFromMartial(martial: number): RenownTier {
  if (martial >= 92) return 'renomado';
  if (martial >= 78) return 'imponente';
  if (martial >= 62) return 'reconhecido';
  if (martial >= 45) return 'forte';
  return 'comum';
}

export function buildInitialState(seed: number, params: NewGameParams, baseState: Omit<GameState,
  'version'|'date'|'playerId'|'playerHouseId'|'houses'|'characters'|'chronicle'|'chat'|'ironBankDebt'|'ui'
> & {houses: Record<string, HouseState>, characters: Record<string, Character>}): GameState {

  const rng = new Rng(seed);

  // 1) Clona as casas e cria relações base
  const houses: Record<string, HouseState> = {};
  for (const [id, h] of Object.entries(baseState.houses)) {
    houses[id] = {
      ...h,
      prestige: clamp(h.prestigeBase, 1, 100),
      relations: {},
      leaderId: '', // será preenchido quando gerar personagens
      economy: {
        peasants: rng.int(650, 1200),
        soldiers: rng.int(80, 140),
        farms: rng.int(2, 5),
        trainingGrounds: rng.int(0, 1),
        walls: rng.int(0, 1),
        tradeLastDelegationTurn: 0,
        tradePartners: [],
      },
      resources: {
        gold: rng.int(400, 900),
        food: rng.int(700, 1200),
      },
      army: {
        levies: rng.int(60, 120),
        menAtArms: rng.int(20, 60),
        squires: rng.int(0, 20),
        knights: rng.int(0, 10),
        dragons: 0,
        stationedRatio: 0.7,
      },
    };
  }

  // relações iniciais
  const houseIds = Object.keys(houses);
  for (const a of houseIds) {
    for (const b of houseIds) {
      if (a === b) continue;
      const ha = houses[a];
      const hb = houses[b];
      let rel = 45;
      if (hb.isIronThrone) rel = 60;
      if (ha.isIronThrone) rel = 55;
      if (ha.regionId === hb.regionId) rel = 58;
      if (ha.suzerainId && ha.suzerainId === b) rel = 62;
      if (hb.suzerainId && hb.suzerainId === a) rel = 55;
      // rivalidade leve com distâncias de prestígio grandes
      const delta = hb.prestigeBase - ha.prestigeBase;
      rel += clamp(-Math.floor(Math.abs(delta) / 12), -10, 0);
      ha.relations[b] = clamp(rel + rng.int(-6, 6), 0, 100);
    }
  }

  // 2) Gera personagens: um pequeno "elenco" por casa (líder + consorte + 2-4 filhos + 1 parente)
  const characters: Record<string, Character> = {};

  function mkChar(houseId: string, gender: Gender, age: number, locationId: string, martialBase: number): Character {
    const name = genFirstName(rng, gender) + maybeEpithet(rng);
    const beauty = clamp(rng.int(25, 65) + (martialBase > 60 ? 8 : 0), 0, 100);
    const charm = clamp(rng.int(25, 70), 0, 100);
    const wellLiked = clamp(rng.int(25, 75), 0, 100);
    const martial = clamp(martialBase + rng.int(-10, 10), 0, 100);


    const personalPrestige = clamp(rng.int(6, 22) + (martial > 60 ? 6 : 0) + (houseId.includes('targaryen') ? 6 : 0), 0, 100);

    // esterilidade baixa para "personagens fictícios"
    const fertility: 'fertile' | 'sterile' = rng.chance(0.05) ? 'sterile' : 'fertile';

    const id = uid('c');
    const c: Character = {
      id,
      name,
      gender,
      ageYears: age,
      alive: true,

      birthHouseId: houseId,
      currentHouseId: houseId,

      maritalStatus: 'single',
      keepsBirthName: false,

      locationId,

      martial,
      charm,
      beauty,
      renownTier: renownFromMartial(martial),
      fertility,
      wellLiked,
      personalPrestige,

      knownToPlayer: false,
      relationshipToPlayer: 0,
    };
    characters[id] = c;
    return c;
  }

  function marry(a: Character, b: Character, keepName: boolean): void {
    a.spouseId = b.id;
    b.spouseId = a.id;
    a.maritalStatus = 'married';
    b.maritalStatus = 'married';

    // Regra de sobrenome: normalmente a mulher vai para a casa do marido
    if (a.gender === 'F' && b.gender === 'M') {
      a.keepsBirthName = keepName;
      if (!keepName) a.currentHouseId = b.currentHouseId;
    } else if (b.gender === 'F' && a.gender === 'M') {
      b.keepsBirthName = keepName;
      if (!keepName) b.currentHouseId = a.currentHouseId;
    }
  }

  function addChild(father: Character, mother: Character, gender: Gender, age: number, locationId: string): Character {
    const childHouseId = father.currentHouseId; // regra do jogo: sem bastardos, filhos seguem o sobrenome dominante
    const child = mkChar(childHouseId, gender, age, locationId, rng.int(10, 35));
    child.fatherId = father.id;
    child.motherId = mother.id;
    return child;
  }

  // para cada casa, cria um líder e família
  for (const houseId of houseIds) {
    const house = houses[houseId];
    const seat = house.seatLocationId;

    const lordGender: Gender = rng.chance(0.18) ? 'F' : 'M'; // raramente líder mulher
    const lordAge = rng.int(38, 58);
    const leader = mkChar(houseId, lordGender, lordAge, seat, rng.int(35, 72));
    leader.title = titleForHouse(houseId, lordGender);
    house.leaderId = leader.id;

    // consorte
    const spouseGender: Gender = lordGender === 'M' ? 'F' : 'M';
    const spouse = mkChar(houseId, spouseGender, rng.int(30, 52), seat, rng.int(15, 45));
    spouse.title = spouseGender === 'F' ? 'Lady Consorte' : 'Lorde Consorte';
    marry(lordGender === 'M' ? leader : spouse, lordGender === 'F' ? leader : spouse, false);

    // filhos
    const childCount = rng.int(2, 4);
    const children: Character[] = [];
    for (let i=0;i<childCount;i++){
      const g: Gender = rng.chance(0.55) ? 'M' : 'F';
      const age = rng.int(8, 24);
      const child = addChild(lordGender === 'M' ? leader : spouse, lordGender === 'F' ? leader : spouse, g, age, seat);
      children.push(child);
    }

    // irmão/irmã do líder
    const sib = mkChar(houseId, rng.chance(0.55) ? 'M' : 'F', rng.int(30, 55), seat, rng.int(20, 55));
    sib.title = 'Parente da Casa';

    // trade partners iniciais: 1-3 casas da mesma região (pré-definido)
    const sameRegion = houseIds.filter((id) => id !== houseId && houses[id].regionId === house.regionId);
    house.economy.tradePartners = rng.int(1, 3) > 0 ? sameRegion.slice(0, Math.min(sameRegion.length, rng.int(1,3))) : [];
    house.economy.tradeLastDelegationTurn = 0;
  }

  // 3) cria jogador como último na sucessão da casa escolhida
  const playerHouse = houses[params.playerHouseId];
  const playerSeat = playerHouse.seatLocationId;

  // pega líder e consorte para criar o jogador como filho(a) mais novo(a)
  const leader = characters[playerHouse.leaderId];
  const spouse = leader.spouseId ? characters[leader.spouseId] : undefined;

  const player = mkChar(params.playerHouseId, params.gender, 18, playerSeat, rng.int(22, 45));
  player.title = params.gender === 'M' ? 'Herdeiro Distante' : 'Herdeira Distante';

  if (spouse && leader.gender !== spouse.gender) {
    // define como filho do casal (jogador como último)
    if (leader.gender === 'M') {
      player.fatherId = leader.id;
      player.motherId = spouse.id;
    } else {
      player.motherId = leader.id;
      player.fatherId = spouse.id;
    }
  } else {
    player.fatherId = leader.id;
  }

  // coloca o jogador como conhecido apenas de pessoas locais (mesma região e mesma localização)
  for (const c of Object.values(characters)) {
    if (c.locationId === playerSeat && houses[c.currentHouseId]?.regionId === playerHouse.regionId) {
      c.knownToPlayer = true;
      c.relationshipToPlayer = clamp(35 + rng.int(-10, 10), 0, 100);
    }
  }
  player.knownToPlayer = true;
  player.relationshipToPlayer = 50;

  player.personalPrestige = clamp(player.personalPrestige ?? 12, 0, 100);

  // 4) estado final
  const state: GameState = {
    version: 3,
    date: { year: 150, turn: 1, absoluteTurn: 1 },

    game: { over: false, victory: false, reason: '' },
    endgame: {
      wallBreached: false,
      danyArrived: false,
      danyRelation: 0,
      kingsLandingBurned: false,
    },

    playerId: player.id,
    playerHouseId: player.currentHouseId,

    locations: baseState.locations,
    regions: baseState.regions,
    travelGraph: baseState.travelGraph,

    houses,
    characters,

    tournaments: [],

    chronicle: [],
    chat: [],

    ironBankDebt: null,

    ui: { activeTab: 'chat', showSetup: false, pendingNameQueue: [] },
  };

  // Mensagem inicial
  pushNarration(state,
    'Você desperta em uma Westeros ainda marcada por cicatrizes antigas, agora no ano 150 DC, sob o reinado de Aegon III.
' +
    `Você é ${player.name}, da ${houses[player.currentHouseId].name}, com 18 anos — o último na linha de sucessão principal.
` +
    'Seu futuro depende de escolhas: alianças, casamentos, guerras, comércio e honra.'
  );

  promptMainMenu(state, rng);
  return state;
}

export function titleForHouse(houseId: string, gender: Gender): string {
  // títulos simples e coerentes com a fantasia (sem tentar “cobrir tudo”)
  const base = gender === 'M' ? 'Lorde' : 'Lady';
  switch (houseId) {
    case 'stark': return gender === 'M' ? 'Protetor do Norte' : 'Protetora do Norte';
    case 'arryn': return gender === 'M' ? 'Protetor do Vale' : 'Protetora do Vale';
    case 'tully': return gender === 'M' ? 'Senhor de Correrrio' : 'Senhora de Correrrio';
    case 'greyjoy': return gender === 'M' ? 'Lorde das Ilhas de Ferro' : 'Lady das Ilhas de Ferro';
    case 'lannister': return gender === 'M' ? 'Senhor de Rochedo Casterly' : 'Senhora de Rochedo Casterly';
    case 'baratheon': return gender === 'M' ? 'Senhor de Ponta Tempestade' : 'Senhora de Ponta Tempestade';
    case 'tyrell': return gender === 'M' ? 'Senhor de Jardim de Cima' : 'Senhora de Jardim de Cima';
    case 'martell': return gender === 'M' ? 'Príncipe de Dorne' : 'Princesa de Dorne';
    case 'targaryen_throne': return gender === 'M' ? 'Rei dos Nove Reinos' : 'Rainha dos Nove Reinos';
    default: return `${base} de ${houseId}`;
  }
}

export function promptMainMenu(state: GameState, rng: Rng): void {
  if (state.game.over) {
    return pushSystem(state, `Fim de jogo. Motivo: ${state.game.reason}`, [
      { id: 'saves', label: 'Abrir Saves' },
      { id: 'reset', label: 'Reiniciar (voltar ao menu inicial)' },
    ]);
  }

  const player = state.characters[state.playerId];
  const playerHouse = state.houses[state.playerHouseId];
  const isLeader = playerHouse.leaderId === player.id;

  const choices: Choice[] = [
    { id: 'travel', label: 'Viajar', hint: 'Mover-se no mapa consumindo comida (risco de encontro)' },
    { id: 'local', label: 'Pessoas no local', hint: 'Ver quem está aqui e interagir (conversa, bebida, caça, flores)' },
    { id: 'tournaments', label: 'Torneios', hint: 'Ver torneios anunciados e participar/organizar' },
    { id: 'diplomacy', label: 'Diplomacia', hint: 'Conversar, presentear, negociar, casamentos, Banco de Ferro' },
    { id: 'train', label: 'Treinar', hint: 'Melhorar combate/beleza e renome' },
    { id: 'chronicle', label: 'Crônicas', hint: 'Ver eventos do reino e deste turno' },
    { id: 'end_turn', label: 'Encerrar turno', hint: 'Avança o tempo (1/20 de ano)' },
  ];

  if (isLeader) choices.splice(2, 0, { id: 'house', label: 'Gerenciar Casa', hint: 'População, fazendas, exército, tributos, delegações' });

  choices.push({ id: 'saves', label: 'Salvar/Carregar', hint: '3 slots de salvamento' });

  pushSystem(state, `Turno ${state.date.turn}/20 • Ano ${state.date.year} DC — O que você fará?`, choices);
}


export function promptLocal(state: GameState, rng: Rng): void {
  const player = state.characters[state.playerId];
  const here = player.locationId;
  const locName = state.locations[here]?.name ?? 'local';
  pushNarration(state, `📍 Você olha ao redor em ${locName}. Abra a aba “Local” para ver personagens presentes e interagir.`);
  // volta ao menu principal para decisões rápidas
  promptMainMenu(state, rng);
}

export function promptTournaments(state: GameState, rng: Rng): void {
  const open = state.tournaments.filter(t => t.status === 'anunciado').length;
  pushNarration(state, `🏇 Torneios anunciados: ${open}. Abra a aba “Torneios” para detalhes, organizar ou participar.`);
  promptMainMenu(state, rng);
}

export function applyChoice(state: GameState, rng: Rng, choiceId: string): void {
  if (state.game.over && !['saves', 'reset'].includes(choiceId)) return;
  const last = state.chat.at(-1);
  if (!last || !last.choices || last.chosenId) return;
  last.chosenId = choiceId;

  switch (choiceId) {
    case 'travel': return promptTravel(state, rng);
    case 'local': state.ui.activeTab = 'local'; return promptLocal(state, rng);
    case 'tournaments': state.ui.activeTab = 'tournaments'; return promptTournaments(state, rng);
    case 'diplomacy': state.ui.activeTab = 'diplomacy'; return promptDiplomacy(state, rng);
    case 'train': return promptTraining(state, rng);
    case 'house': state.ui.activeTab = 'house'; return promptHouseMgmt(state, rng);
    case 'chronicle': state.ui.activeTab = 'chronicle'; return promptChronicle(state, rng);
    case 'saves': state.ui.activeTab = 'saves'; return pushNarration(state, 'Abra a aba “Saves” para salvar/carregar em 3 slots.');
    case 'end_turn': return advanceTurn(state, rng);
  }
}

function pushSystem(state: GameState, text: string, choices?: Choice[]): void {
  state.chat.push({
    id: uid('m'),
    speaker: 'sistema',
    text,
    tsTurn: state.date.absoluteTurn,
    choices,
  });
}

function pushNarration(state: GameState, text: string): void {
  state.chat.push({
    id: uid('m'),
    speaker: 'narrador',
    text,
    tsTurn: state.date.absoluteTurn,
  });
}

function pushNpc(state: GameState, title: string, text: string): void {
  state.chat.push({
    id: uid('m'),
    speaker: 'npc',
    title,
    text,
    tsTurn: state.date.absoluteTurn,
  });
}

function setGameOver(state: GameState, reason: string, victory: boolean): void {
  state.game.over = true;
  state.game.victory = victory;
  state.game.reason = reason;

  const title = victory ? '🏆 Fim da Crônica (Vitória)' : '☠️ Fim da Crônica (Game Over)';
  pushNarration(state, `${title}: ${reason}`);
  pushSystem(state, 'Você pode carregar um save (3 slots) ou reiniciar a campanha.', [
    { id: 'saves', label: 'Abrir Saves' },
    { id: 'reset', label: 'Reiniciar (voltar ao menu inicial)' },
  ]);
}

function setVictory(state: GameState, reason: string): void {
  setGameOver(state, reason, true);
}

function computeArmyPower(army: Army): number {
  // Unidades em massa só vão até cavaleiros.
  // Dragões (quando presentes) contam como equivalentes a 10.000 cavaleiros por dragão.
  const knightsEq = army.knights + (army.dragons * 10000);
  return (
    (army.levies * 1) +
    (army.menAtArms * 2) +
    (army.squires * 3) +
    (knightsEq * 4)
  );
}

function ensureDaenerysFaction(state: GameState, rng: Rng): void {
  if (state.endgame.danyArrived) return;

  // Cria casa + Daenerys apenas quando ela "chega".
  const kl = Object.values(state.locations).find(l => l.name.toLowerCase().includes('porto real') || l.id === 'kings_landing')?.id
    ?? Object.values(state.locations)[0].id;

  state.houses[DANY_HOUSE_ID] = {
    id: DANY_HOUSE_ID,
    name: 'Casa Targaryen (Daenerys)',
    regionId: 'crownlands',
    seatLocationId: kl,
    prestigeBase: 96,
    prestige: 96,
    relations: {},
    leaderId: '',
    economy: {
      peasants: 0,
      soldiers: 0,
      farms: 0,
      trainingGrounds: 0,
      walls: 0,
      tradeLastDelegationTurn: 0,
      tradePartners: [],
    },
    resources: {
      gold: 12000,
      food: 9000,
    },
    army: {
      levies: 0,
      menAtArms: 9000, // Imaculados (abstração)
      squires: 0,
      knights: 2500,   // elite + cavaleiros aliados (abstração)
      dragons: 3,      // sem mecânica; só equivalência em poder
      stationedRatio: 0.0,
    },
  };

  // Relações iniciais com as outras casas
  for (const h of Object.values(state.houses)) {
    if (h.id === DANY_HOUSE_ID) continue;
    const base = clamp(35 + Math.floor((h.prestige - 50) / 3), 5, 70);
    h.relations[DANY_HOUSE_ID] = base;
    state.houses[DANY_HOUSE_ID].relations[h.id] = clamp(40 + rng.int(-8, 8), 0, 100);
  }

  // Daenerys como personagem
  const id = uid('c');
  state.characters[id] = {
    id,
    name: 'Daenerys Targaryen',
    gender: 'F',
    ageYears: 19,
    alive: true,

    birthHouseId: DANY_HOUSE_ID,
    currentHouseId: DANY_HOUSE_ID,

    maritalStatus: 'single',
    keepsBirthName: true,

    locationId: kl,

    martial: 25,
    charm: 88,
    beauty: 82,
    renownTier: 'comum',
    fertility: 'fertile',
    wellLiked: 65,

    knownToPlayer: true,
    relationshipToPlayer: 10,

    title: 'Pretendente ao Trono',
  };
  state.houses[DANY_HOUSE_ID].leaderId = id;

  state.endgame.danyArrived = true;
  state.endgame.danyHouseId = DANY_HOUSE_ID;
  state.endgame.danyLeaderId = id;
  state.endgame.danyRelation = 10;
}

function promptTravel(state: GameState, rng: Rng): void {
  state.ui.activeTab = 'map';
  const player = state.characters[state.playerId];
  const here = state.locations[player.locationId];
  const options = state.travelGraph[here.id] ?? [];

  if (options.length === 0) {
    pushNarration(state, 'Você está em um local sem rotas mapeadas. (Você pode expandir TRAVEL_GRAPH em src/app/core/data/regions.ts)');
    return promptMainMenu(state, rng);
  }

  const armySize = getActiveArmySize(state, 1.0);
  const base = `Você está em **${here.name}**. Escolha um destino.
` +
    `Levar mais exército aumenta custo de comida e reduz risco de emboscada.`;

  const choices: Choice[] = [];
  for (const opt of options) {
    const to = state.locations[opt.toLocationId];
    const foodCost = travelFoodCost(state, opt.distance, armySize);
    choices.push({ id: `go:${to.id}`, label: `Ir para ${to.name}`, hint: `Distância ${opt.distance} • Custo ~${foodCost} comida` });
  }
  choices.push({ id: 'back', label: 'Voltar', hint: 'Retorna ao menu principal' });

  pushSystem(state, base, choices);
}

function travelFoodCost(state: GameState, distance: number, armySize: number): number {
  const playerHouse = state.houses[state.playerHouseId];
  const pop = playerHouse.economy.peasants + playerHouse.economy.soldiers;
  const scale = 1 + clamp(armySize / 250, 0, 2.0);
  // custo simplificado
  return Math.max(5, Math.round(distance * 16 * scale));
}

function getActiveArmySize(state: GameState, marchingRatio: number): number {
  const army = state.houses[state.playerHouseId].army;
  const total = army.levies + army.menAtArms + army.squires + army.knights;
  return Math.round(total * marchingRatio);
}

export function applyTravel(state: GameState, rng: Rng, toLocationId: string): void {
  const player = state.characters[state.playerId];
  const from = state.locations[player.locationId];
  const edges = state.travelGraph[from.id] ?? [];
  const edge = edges.find((e) => e.toLocationId === toLocationId);
  if (!edge) {
    pushNarration(state, 'Caminho inválido.');
    return promptMainMenu(state, rng);
  }

  // custo
  const armySize = getActiveArmySize(state, 0.6); // padrão: marcha com 60% (o resto fica)
  const cost = travelFoodCost(state, edge.distance, armySize);
  const house = state.houses[state.playerHouseId];
  if (house.resources.food < cost) {
    pushNarration(state, 'Comida insuficiente para a viagem. Produza mais (fazendas/camponeses) ou negocie comércio.');
    return promptMainMenu(state, rng);
  }
  house.resources.food -= cost;

  // encontro
  const risk = travelEncounterRisk(state, from.regionId, armySize, house.prestige);
  pushNarration(state, `Você parte rumo a ${state.locations[toLocationId].name} (custo ${cost} comida).`);

  if (rng.chance(risk)) {
    resolveEncounter(state, rng, armySize);
    // pode morrer aqui
    if (!state.characters[state.playerId].alive) return;
  } else {
    pushNarration(state, 'A estrada foi silenciosa. Apenas o vento e os corvos como testemunhas.');
  }

  player.locationId = toLocationId;

  // conhecer gente local automaticamente
  markLocalsKnown(state, rng, toLocationId);

  promptMainMenu(state, rng);
}

function travelEncounterRisk(state: GameState, regionId: string, armySize: number, prestige: number): number {
  // base por região (norte e rios um pouco mais perigosos)
  let base = 0.10;
  if (regionId === 'north') base = 0.14;
  if (regionId === 'riverlands') base = 0.13;
  if (regionId === 'iron_islands') base = 0.12;
  if (regionId === 'reach') base = 0.08;

  // exército reduz risco
  const armyFactor = clamp(1 - armySize / 260, 0.25, 1);
  // prestígio reduz risco (medo/respeito)
  const prestigeFactor = clamp(1 - prestige / 250, 0.6, 1);
  return clamp(base * armyFactor * prestigeFactor, 0.02, 0.25);
}

function resolveEncounter(state: GameState, rng: Rng, armySize: number): void {
  const player = state.characters[state.playerId];
  const house = state.houses[state.playerHouseId];

  const bandits = rng.int(18, 120);
  const banditPower = bandits * rng.int(1, 3);

  const playerPower = Math.round(
    (armySize * 2.0) +
    (house.army.knights * 12) +
    (house.army.squires * 6) +
    (house.army.menAtArms * 4) +
    (player.martial * 2)
  );

  pushNpc(state, 'Batedor', `Emboscada na estrada! Um grupo de ${bandits} bandidos tenta cercar sua comitiva.`);

  const winChance = clamp(playerPower / (playerPower + banditPower), 0.1, 0.9);
  if (rng.chance(winChance)) {
    const lootGold = rng.int(20, 120);
    const lootFood = rng.int(30, 140);
    house.resources.gold += lootGold;
    house.resources.food += lootFood;
    house.prestige = clamp(house.prestige + 1, 1, 100);

    pushNarration(state, `Você repele os bandidos e recolhe espólios: +${lootGold} ouro, +${lootFood} comida. Prestígio +1.`);
  } else {
    // chance de morte do jogador na derrota
    const deathChance = clamp(0.30 + (banditPower - playerPower) / 900, 0.25, 0.80);
    if (rng.chance(deathChance)) {
      player.alive = false;
      pushNarration(state, 'A emboscada dá errado. Sua visão escurece — e o mundo segue sem você.');
      handlePlayerDeath(state, rng, 'Morte em emboscada');
      return;
    }
    const lossGold = Math.min(house.resources.gold, rng.int(40, 180));
    const lossFood = Math.min(house.resources.food, rng.int(60, 220));
    house.resources.gold -= lossGold;
    house.resources.food -= lossFood;
    house.prestige = clamp(house.prestige - 2, 1, 100);

    pushNarration(state, `Você consegue escapar, mas paga caro: -${lossGold} ouro, -${lossFood} comida. Prestígio -2.`);
  }
}

function markLocalsKnown(state: GameState, rng: Rng, locationId: string): void {
  const playerHouse = state.houses[state.playerHouseId];
  const regionId = state.locations[locationId].regionId;

  const localChars = Object.values(state.characters)
    .filter(c => c.alive && c.locationId === locationId && state.houses[c.currentHouseId]?.regionId === regionId);

  // garante que algumas pessoas locais sejam “conhecidas”
  for (const c of localChars.slice(0, 6)) {
    if (!c.knownToPlayer) {
      c.knownToPlayer = true;
      c.relationshipToPlayer = clamp(25 + rng.int(-5, 10), 0, 100);
      pushNarration(state, `Você passa a conhecer ${c.name} (${state.houses[c.currentHouseId]?.name ?? 'Casa desconhecida'}).`);
    }
  }
}


function isRegionalSuzerain(state: GameState, h: HouseState): boolean {
  // aproximação: prestígio de suserano e vassalagem direta ao Trono (exceto Terras da Coroa)
  return !h.isIronThrone && h.prestige >= 76 && h.suzerainId === 'targaryen_throne' && h.regionId !== 'crownlands';
}

function computeContactableHouses(state: GameState): HouseState[] {
  const playerHouse = state.houses[state.playerHouseId];
  const sameRegion = Object.values(state.houses).filter(h => h.regionId === playerHouse.regionId);

  const set = new Map<string, HouseState>();
  for (const h of sameRegion) set.set(h.id, h);

  if (playerHouse.suzerainId && state.houses[playerHouse.suzerainId]) {
    set.set(playerHouse.suzerainId, state.houses[playerHouse.suzerainId]);
  }

  const playerIsSuzerain = Object.values(state.houses).some(h => h.suzerainId === playerHouse.id);
  const playerIsHighPrestige = playerHouse.prestige >= 76 || playerIsSuzerain;
  const iron = Object.values(state.houses).find(h => h.isIronThrone);

  if (playerHouse.isIronThrone) {
    // A Coroa fala basicamente com suseranos regionais e nobres do nível de suserano
    for (const h of Object.values(state.houses)) {
      if (isRegionalSuzerain(state, h) || (h.prestige >= 76 && !h.isIronThrone)) set.set(h.id, h);
    }
  } else if (playerIsHighPrestige) {
    // Suseranos/nobres prestigiados podem falar com: outros suseranos + casas nobres relevantes fora da região + Coroa
    for (const h of Object.values(state.houses)) {
      if (h.regionId === playerHouse.regionId) continue;
      if (isRegionalSuzerain(state, h) || h.prestige >= 51) set.set(h.id, h);
    }
    if (iron) set.set(iron.id, iron);
  }

  return [...set.values()].sort((a,b)=> b.prestige - a.prestige);
}

function promptDiplomacy(state: GameState, rng: Rng): void {
  const player = state.characters[state.playerId];
  const here = state.locations[player.locationId];
  const regionId = here.regionId;
  const playerHouse = state.houses[state.playerHouseId];

  const nearbyHouses = Object.values(state.houses)
    .filter(h => h.regionId === regionId)
    .sort((a,b) => b.prestige - a.prestige)
    .slice(0, 10);

  const lines = nearbyHouses.map(h => {
    const rel = playerHouse.relations[h.id] ?? 50;
    return `• ${h.name} — Prestígio ${h.prestige} • Relação ${rel}`;
  }).join('
');

  const text =
    `Você está em ${here.name} (${state.regions[regionId].name}).
` +
    `Casas da região (top 10):
${lines}

` +
    `Escolha uma ação diplomática:`;

  const choices: Choice[] = [
    { id: 'dip:talk', label: 'Conversar', hint: 'Melhora relação com uma pessoa conhecida (leve)' },
    { id: 'dip:gift', label: 'Dar presente', hint: 'Custa ouro, melhora relação (médio)' },
    { id: 'dip:audience', label: 'Pedir audiência', hint: 'Tentar contato com casas mais prestigiosas (difícil)' },
    { id: 'dip:marriage', label: 'Propor casamento', hint: 'Aliança via casamento (exige boa relação)' },
    ...(state.endgame.danyArrived && !state.endgame.kingsLandingBurned ? [{
      id: 'dip:dany',
      label: 'Daenerys Targaryen',
      hint: 'Negociar / atacar (condição especial de “vitória”)'
    }] as Choice[] : []),
    { id: 'dip:ironbank', label: 'Banco de Ferro', hint: 'Pedir empréstimo / pagar dívida' },
    { id: 'back', label: 'Voltar' },
  ];
  pushSystem(state, text, choices);
}

export function applyDiplomacy(state: GameState, rng: Rng, action: string): void {
  const player = state.characters[state.playerId];
  const house = state.houses[state.playerHouseId];

  switch (action) {
    case 'dany': {
      if (!state.endgame.danyArrived || state.endgame.kingsLandingBurned) {
        pushNarration(state, 'Você não consegue mais alcançar Daenerys a tempo.');
        return promptMainMenu(state, rng);
      }
      const rel = clamp(state.endgame.danyRelation, 0, 100);
      const p = state.characters[state.playerId];
      const genderOk = p.gender === 'M';
      const married = p.maritalStatus === 'married';

      const choices: Choice[] = [
        { id: 'dany:talk', label: 'Conversar', hint: `Relação com Daenerys: ${rel}/100` },
        { id: 'dany:gift', label: 'Enviar presente', hint: 'Custa ouro, melhora relação' },
        { id: 'dany:ally', label: 'Oferecer apoio', hint: 'Tenta evitar conflito (não é “vitória”)' },
        {
          id: 'dany:marry',
          label: 'Propor casamento',
          disabled: !genderOk || married,
          hint: genderOk ? (married ? 'Você já é casado.' : 'Requer relação muito alta (90+)') : 'Relações apenas heterossexuais: seu personagem precisa ser masculino.'
        },
        { id: 'dany:attack', label: 'Atacar Daenerys', hint: 'Batalha arriscada contra um exército quase impossível' },
        { id: 'back', label: 'Voltar' },
      ];

      pushSystem(state,
        `Daenerys Targaryen está em Westeros. Relação atual: ${rel}/100.
\nSem mecânica de dragões em cena — mas, em batalha, cada dragão equivale a 10.000 cavaleiros.`,
        choices
      );
      return;
    }
    case 'talk': {
      const known = Object.values(state.characters)
        .filter(c => c.alive && c.knownToPlayer && c.id !== player.id && c.locationId === player.locationId)
        .slice(0, 8);

      if (known.length === 0) {
        pushNarration(state, 'Não há conhecidos por perto. Viaje, faça torneios ou peça audiência.');
        return promptMainMenu(state, rng);
      }
      const choices: Choice[] = known.map(c => ({
        id: `talk:${c.id}`,
        label: `Conversar com ${c.name}`,
        hint: `Relação atual ${c.relationshipToPlayer}/100`
      }));
      choices.push({ id: 'back', label: 'Voltar' });
      pushSystem(state, 'Com quem você quer conversar?', choices);
      return;
    }
    case 'gift': {
      const known = Object.values(state.characters)
        .filter(c => c.alive && c.knownToPlayer && c.id !== player.id && c.locationId === player.locationId)
        .slice(0, 8);
      if (known.length === 0) {
        pushNarration(state, 'Você precisa conhecer alguém primeiro.');
        return promptMainMenu(state, rng);
      }
      const choices: Choice[] = known.map(c => ({
        id: `gift:${c.id}`,
        label: `Presentear ${c.name}`,
        hint: `Custo 35 ouro • Relação +6~+14`
      }));
      choices.push({ id: 'back', label: 'Voltar' });
      pushSystem(state, 'Presentes: flores raras, vinho de Arbor, seda de Lys (abstrato). Quem receberá?', choices);
      return;
    }
    case 'audience': {
      // lista de casas acima do seu prestígio
      const regionHouses = Object.values(state.houses)
        .filter(h => h.regionId === state.locations[player.locationId].regionId && h.id !== house.id)
        .sort((a,b)=> b.prestige - a.prestige)
        .slice(0, 8);

      const choices: Choice[] = regionHouses.map(h => {
        const rel = house.relations[h.id] ?? 50;
        const delta = h.prestige - house.prestige;
        const hint = `Prestígio ${h.prestige} (Δ ${delta}) • Relação ${rel} • Sucesso depende do seu prestígio`;
        return { id: `aud:${h.id}`, label: `Pedir audiência à ${h.name}`, hint };
      });
      choices.push({ id: 'back', label: 'Voltar' });
      pushSystem(state, 'A quem você tentará acesso?', choices);
      return;
    }
    case 'marriage': {
      pushNarration(state, 'Sistema de casamento: nesta versão, você propõe ao nível de Casa (não personagem específico) e o jogo escolhe um par plausível.');
      const candidates = Object.values(state.houses)
        .filter(h => h.id !== house.id)
        .sort((a,b)=> b.prestige - a.prestige)
        .slice(0, 10);

      const choices: Choice[] = candidates.map(h => {
        const rel = house.relations[h.id] ?? 50;
        const ok = rel >= 50;
        return { id: `mar:${h.id}`, label: `Propor aliança/casamento com ${h.name}`, hint: ok ? `Relação ${rel} (ok)` : `Relação ${rel} (mín. 50)` , disabled: !ok };
      });
      choices.push({ id: 'back', label: 'Voltar' });
      pushSystem(state, 'Qual casa receberá a proposta? (mínimo relação 50)', choices);
      return;
    }
    case 'ironbank': {
      const debt = state.ironBankDebt;
      if (!debt) {
        pushSystem(state, 'Banco de Ferro (Braavos): você pode pedir um empréstimo. Juros 12% a.a. (cobrança a cada 20 turnos).', [
          { id: 'ib:loan:300', label: 'Pedir 300 ouro', hint: 'Prestígio -1 (suspeitas), +300 ouro' },
          { id: 'ib:loan:600', label: 'Pedir 600 ouro', hint: 'Prestígio -2, +600 ouro' },
          { id: 'ib:loan:1000', label: 'Pedir 1000 ouro', hint: 'Prestígio -3, +1000 ouro' },
          { id: 'back', label: 'Voltar' },
        ]);
      } else {
        pushSystem(state,
          `Dívida ativa: principal ${debt.principal} • juros ${Math.round(debt.interestRateYear*100)}% a.a.
` +
          `Pagamento mínimo: ${debt.minimumPayment} ouro • Próxima cobrança no turno ${debt.nextPaymentTurn}.
` +
          `Atrasos: ${debt.missedPayments}.`,
          [
            { id: 'ib:paymin', label: 'Pagar mínimo', hint: 'Reduz risco de intervenção' },
            { id: 'ib:payall', label: 'Quitar tudo', hint: 'Limpa dívida, prestígio +1' },
            { id: 'back', label: 'Voltar' },
          ]
        );
      }
      return;
    }
  }
}

export function applyDiplomacyChoice(state: GameState, rng: Rng, action: string, targetId: string): void {
  const player = state.characters[state.playerId];
  const house = state.houses[state.playerHouseId];

  if (action === 'talk') {
    const target = state.characters[targetId];
    if (!target || !target.alive) {
      pushNarration(state, 'Essa pessoa não está disponível.');
      return promptMainMenu(state, rng);
    }
    const gain = rng.int(2, 6);
    target.relationshipToPlayer = clamp(target.relationshipToPlayer + gain, 0, 100);
    // relação entre casas também sobe levemente
    house.relations[target.currentHouseId] = clamp((house.relations[target.currentHouseId] ?? 50) + 1, 0, 100);
    pushNpc(state, target.name, '“O mundo é grande… e perigoso. Ainda bem que existem amigos.”');
    pushNarration(state, `Relação pessoal +${gain}. Relação entre casas +1.`);
    return promptMainMenu(state, rng);
  }

  if (action === 'gift') {
    const target = state.characters[targetId];
    if (!target || !target.alive) {
      pushNarration(state, 'Essa pessoa não está disponível.');
      return promptMainMenu(state, rng);
    }
    if (house.resources.gold < 35) {
      pushNarration(state, 'Ouro insuficiente para um presente digno.');
      return promptMainMenu(state, rng);
    }
    house.resources.gold -= 35;
    const gain = rng.int(6, 14);
    target.relationshipToPlayer = clamp(target.relationshipToPlayer + gain, 0, 100);
    house.relations[target.currentHouseId] = clamp((house.relations[target.currentHouseId] ?? 50) + rng.int(2, 5), 0, 100);
    pushNpc(state, target.name, '“Isso… é mais do que eu esperava. Você tem minha atenção.”');
    pushNarration(state, `Você gasta 35 ouro. Relação pessoal +${gain}. Relação entre casas melhora.`);
    return promptMainMenu(state, rng);
  }

  if (action === 'aud') {
    const targetHouse = state.houses[targetId];
    if (!targetHouse) {
      pushNarration(state, 'Casa inválida.');
      return promptMainMenu(state, rng);
    }
    const rel = house.relations[targetHouse.id] ?? 50;
    const prestigeGap = targetHouse.prestige - house.prestige;
    // dificuldade aumenta com gap; relação ajuda
    const base = 0.45 - clamp(prestigeGap / 120, 0, 0.35) + clamp((rel - 50) / 200, -0.10, 0.20);
    const chance = clamp(base, 0.08, 0.75);

    if (rng.chance(chance)) {
      // cria um NPC representante da casa se não existir na localização
      const rep = spawnEnvoy(state, rng, targetHouse.id, player.locationId);
      rep.knownToPlayer = true;
      rep.relationshipToPlayer = clamp(30 + rng.int(-5, 10), 0, 100);

      pushNarration(state, `Você consegue uma audiência. Um emissário de ${targetHouse.name} lhe recebe.`);
      pushNpc(state, rep.name, '“Fale. Mas seja breve.”');
      // melhora relação entre casas pelo gesto
      house.relations[targetHouse.id] = clamp(rel + rng.int(2, 6), 0, 100);
    } else {
      pushNarration(state, `A tentativa falha. Guardas e criados lhe fazem esperar… e a porta nunca se abre.`);
      house.relations[targetHouse.id] = clamp(rel - rng.int(1, 4), 0, 100);
      house.prestige = clamp(house.prestige - 1, 1, 100);
    }
    return promptMainMenu(state, rng);
  }

  if (action === 'mar') {
    const targetHouse = state.houses[targetId];
    if (!targetHouse) {
      pushNarration(state, 'Casa inválida.');
      return promptMainMenu(state, rng);
    }
    const rel = house.relations[targetHouse.id] ?? 50;
    if (rel < 50) {
      pushNarration(state, 'Relação insuficiente para uma proposta séria.');
      return promptMainMenu(state, rng);
    }

    // chance base: casas tendem a aceitar igual nível; gap grande reduz
    const gap = targetHouse.prestige - house.prestige;
    const accept = clamp(0.55 - clamp(gap / 120, -0.10, 0.35) + (rel - 50) / 120, 0.15, 0.90);

    if (rng.chance(accept)) {
      // aliança
      house.relations[targetHouse.id] = clamp(rel + rng.int(10, 18), 0, 100);
      targetHouse.relations[house.id] = clamp((targetHouse.relations[house.id] ?? 50) + rng.int(8, 14), 0, 100);

      pushNarration(state, `Proposta aceita. Um pacto de casamento/aliança com ${targetHouse.name} é firmado (em termos gerais).`);
      state.chronicle.unshift({
        turn: state.date.absoluteTurn,
        title: 'Aliança selada',
        body: `${house.name} e ${targetHouse.name} firmam acordos matrimoniais e juram apoio mútuo.`,
        tags: ['aliança', 'casamento']
      });
      // prestígio sobe um pouco
      house.prestige = clamp(house.prestige + 2, 1, 100);
    } else {
      pushNarration(state, `Proposta recusada. A recusa ecoa pelos salões, e sua Casa paga o preço social.`);
      // penalidade depende do gap
      const loss = clamp(2 + Math.floor(Math.max(0, gap) / 18), 2, 10);
      house.prestige = clamp(house.prestige - loss, 1, 100);
      house.relations[targetHouse.id] = clamp(rel - rng.int(4, 10), 0, 100);
    }

    return promptMainMenu(state, rng);
  }

  if (action === 'ib') {
    // handled separately in applyIronBank
  }
}

export function applyDaenerysAction(state: GameState, rng: Rng, action: string): void {
  if (state.game.over) return;
  if (!state.endgame.danyArrived || state.endgame.kingsLandingBurned) {
    pushNarration(state, 'Daenerys não está mais acessível.');
    return promptMainMenu(state, rng);
  }
  const p = state.characters[state.playerId];
  const playerHouse = state.houses[state.playerHouseId];
  const danyHouse = state.houses[DANY_HOUSE_ID];

  const relBefore = clamp(state.endgame.danyRelation, 0, 100);

  if (action === 'talk') {
    const gain = rng.int(3, 7);
    state.endgame.danyRelation = clamp(relBefore + gain, 0, 100);
    pushNpc(state, 'Daenerys', '“Westeros é feito de promessas quebradas. Dê-me uma razão para acreditar na sua.”');
    pushNarration(state, `Relação com Daenerys +${gain}.`);
    return promptMainMenu(state, rng);
  }

  if (action === 'gift') {
    const cost = 120;
    if (playerHouse.resources.gold < cost) {
      pushNarration(state, `Ouro insuficiente. Um gesto que alcance a Rainha Dragão custa pelo menos ${cost} ouro.`);
      return promptMainMenu(state, rng);
    }
    playerHouse.resources.gold -= cost;
    const gain = rng.int(8, 16);
    state.endgame.danyRelation = clamp(relBefore + gain, 0, 100);
    pushNpc(state, 'Daenerys', '“Você entende o valor de um símbolo… e do custo de mantê-lo.”');
    pushNarration(state, `Você gasta ${cost} ouro. Relação com Daenerys +${gain}.`);
    return promptMainMenu(state, rng);
  }

  if (action === 'ally') {
    // Não é "vitória" – apenas melhora relação/evita hostilidade imediata.
    const gain = clamp(4 + Math.floor(playerHouse.prestige / 25), 4, 10);
    state.endgame.danyRelation = clamp(relBefore + gain, 0, 100);
    playerHouse.relations[DANY_HOUSE_ID] = clamp((playerHouse.relations[DANY_HOUSE_ID] ?? 40) + gain, 0, 100);
    pushNarration(state, 'Você oferece apoio político e logístico. Isso não muda o destino do reino… mas muda o olhar que ela lança para você.');
    pushNarration(state, `Relação com Daenerys +${gain}. Relação entre casas melhora.`);
    return promptMainMenu(state, rng);
  }

  if (action === 'marry') {
    if (p.gender !== 'M') {
      pushNarration(state, 'Pelas regras desta campanha, casamentos/romances são apenas heterossexuais.');
      return promptMainMenu(state, rng);
    }
    if (p.maritalStatus === 'married') {
      pushNarration(state, 'Você já é casado.');
      return promptMainMenu(state, rng);
    }
    const rel = clamp(state.endgame.danyRelation, 0, 100);
    if (rel < 90) {
      pushNarration(state, 'Daenerys não aceita. Sua proposta é ousada demais sem confiança absoluta (requer 90+).');
      state.endgame.danyRelation = clamp(rel - 3, 0, 100);
      return promptMainMenu(state, rng);
    }
    if (playerHouse.prestige < 70) {
      pushNarration(state, 'Mesmo com simpatia pessoal, sua Casa não tem peso suficiente para um casamento que reescreva o mundo (requer prestígio 70+).');
      return promptMainMenu(state, rng);
    }

    // Sucesso: vitória.
    pushNarration(state, '📜 Um casamento impensável é firmado. O destino de Westeros se desvia — e a história termina na sua sombra.');
    state.chronicle.unshift({
      turn: state.date.absoluteTurn,
      title: 'Aliança Impossível',
      body: `${playerHouse.name} e Daenerys Targaryen firmam um casamento que muda os Nove Reinos.`,
      tags: ['daenerys', 'casamento', 'vitória'],
    });
    return setVictory(state, 'Você se casou com Daenerys Targaryen — uma vitória rara, conquistada por prestígio e confiança extrema.');
  }

  if (action === 'attack') {
    pushNarration(state, '⚔️ Você escolhe a guerra contra Daenerys.');

    const playerPower = computeArmyPower(playerHouse.army) + (p.martial * 6) + (playerHouse.prestige * 4);
    const danyLeader = state.characters[danyHouse.leaderId];
    const danyPower = computeArmyPower(danyHouse.army) + ((danyLeader?.charm ?? 0) * 2) + (danyHouse.prestige * 4);

    const winChance = clamp(playerPower / (playerPower + danyPower), 0.01, 0.80);
    if (rng.chance(winChance)) {
      state.chronicle.unshift({
        turn: state.date.absoluteTurn,
        title: 'O Impossível Acontece',
        body: `${playerHouse.name} derrota as forças de Daenerys em batalha. Os bardos cantarão por gerações — se houver bardo para cantar.`,
        tags: ['daenerys', 'guerra', 'vitória'],
      });
      return setVictory(state, 'Você derrotou o exército de Daenerys em batalha — a única outra forma de “vencer”.');
    }

    // derrota -> o jogador morre; sucessão segue regra normal (se houver)
    p.alive = false;
    pushNarration(state, '🔥 A batalha é um desastre. O céu se ilumina e o chão vira cinza. Você cai.');
    handlePlayerDeath(state, rng, 'Derrota contra Daenerys');
    return;
  }

  pushNarration(state, 'Ação inválida.');
  return promptMainMenu(state, rng);
}

function spawnEnvoy(state: GameState, rng: Rng, houseId: string, locationId: string): Character {
  const id = uid('c');
  const gender: Gender = rng.chance(0.55) ? 'M' : 'F';
  const name = genFirstName(rng, gender) + maybeEpithet(rng);
  const c: Character = {
    id,
    name,
    gender,
    ageYears: rng.int(20, 45),
    alive: true,

    birthHouseId: houseId,
    currentHouseId: houseId,

    maritalStatus: 'single',
    keepsBirthName: false,

    locationId,

    martial: clamp(rng.int(20, 55), 0, 100),
    charm: clamp(rng.int(30, 70), 0, 100),
    beauty: clamp(rng.int(30, 70), 0, 100),
    renownTier: 'comum',
    fertility: rng.chance(0.05) ? 'sterile' : 'fertile',
    wellLiked: clamp(rng.int(25, 75), 0, 100),

    // emissários são “pessoas” com alguma reputação pessoal, mas baixa
    personalPrestige: clamp(rng.int(0, 12), 0, 100),

    knownToPlayer: true,
    relationshipToPlayer: clamp(25 + rng.int(-10, 10), 0, 100),

    title: 'Emissário',
  };
  state.characters[id] = c;
  return c;
}

function promptTraining(state: GameState, rng: Rng): void {
  const player = state.characters[state.playerId];
  const house = state.houses[state.playerHouseId];

  const text =
    `Treino e aparência.
` +
    `• Combate (martial): aumenta chance de sobreviver e vencer encontros.
` +
    `• Beleza/Apresentação: ajuda em relações e casamentos.
` +
    `• Renome: evolui com martial.

` +
    `Seu martial: ${player.martial} (${player.renownTier}) • beleza: ${player.beauty} • ouro: ${house.resources.gold}`;

  pushSystem(state, text, [
    { id: 'tr:yard', label: 'Treinar no pátio', hint: 'Custo 20 ouro • martial +2~+6' },
    { id: 'tr:attire', label: 'Comprar traje refinado', hint: 'Custo 35 ouro • beleza +3~+8' },
    { id: 'tr:duel', label: 'Sparring arriscado', hint: 'Custo 0 • martial +4~+10 (10% ferimento social: prestígio -1)' },
    { id: 'back', label: 'Voltar' },
  ]);
}

export function applyTraining(state: GameState, rng: Rng, trainingId: string): void {
  const player = state.characters[state.playerId];
  const house = state.houses[state.playerHouseId];

  if (trainingId === 'yard') {
    if (house.resources.gold < 20) {
      pushNarration(state, 'Ouro insuficiente para pagar mestres/armas e equipamentos.');
      return promptMainMenu(state, rng);
    }
    house.resources.gold -= 20;
    const gain = rng.int(2, 6);
    player.martial = clamp(player.martial + gain, 0, 100);
    player.renownTier = renownFromMartial(player.martial);
    pushNarration(state, `Você treina intensamente. Martial +${gain}.`);
    return promptMainMenu(state, rng);
  }

  if (trainingId === 'attire') {
    if (house.resources.gold < 35) {
      pushNarration(state, 'Ouro insuficiente para um traje digno.');
      return promptMainMenu(state, rng);
    }
    house.resources.gold -= 35;
    const gain = rng.int(3, 8);
    player.beauty = clamp(player.beauty + gain, 0, 100);
    pushNarration(state, `Você adquire um traje: “Veludo Sombrio de Lys” e “Fivela de Prata de Valdocaso”. Beleza +${gain}.`);
    return promptMainMenu(state, rng);
  }

  if (trainingId === 'duel') {
    const gain = rng.int(4, 10);
    player.martial = clamp(player.martial + gain, 0, 100);
    player.renownTier = renownFromMartial(player.martial);
    if (rng.chance(0.10)) {
      house.prestige = clamp(house.prestige - 1, 1, 100);
      pushNarration(state, `Você vence por pouco, mas espalham boatos de imprudência. Martial +${gain}, prestígio -1.`);
    } else {
      pushNarration(state, `Sparring brutal e produtivo. Martial +${gain}.`);
    }
    return promptMainMenu(state, rng);
  }
}

function promptHouseMgmt(state: GameState, rng: Rng): void {
  const player = state.characters[state.playerId];
  const house = state.houses[state.playerHouseId];
  const isLeader = house.leaderId === player.id;

  if (!isLeader) {
    pushNarration(state, 'Você ainda não é o líder da Casa. (Herança pode ocorrer por idade, guerra ou eventos de viagem.)');
    return promptMainMenu(state, rng);
  }

  const econ = house.economy;
  const army = house.army;

  const text =
    `Gestão da Casa — ${house.name}
` +
    `Prestígio: ${house.prestige}

` +
    `Economia:
` +
    `• Camponeses: ${econ.peasants}
` +
    `• Soldados (cidadãos armados): ${econ.soldiers}
` +
    `• Fazendas: ${econ.farms}
` +
    `• Campos de treino: ${econ.trainingGrounds}

` +
    `Recursos:
` +
    `• Comida: ${house.resources.food}
` +
    `• Ouro: ${house.resources.gold}

` +
    `Exército:
` +
    `• Levies: ${army.levies} • Homens-de-Armas: ${army.menAtArms} • Escudeiros: ${army.squires} • Cavaleiros: ${army.knights}

` +
    `Delegações comerciais: enviar a cada 5 turnos para manter bônus. Último envio no turno ${econ.tradeLastDelegationTurn}.`;

  pushSystem(state, text, [
    { id: 'hm:farm', label: 'Comprar fazenda', hint: 'Custo 120 ouro • +80 comida/turno (aprox.) • +40 camponeses' },
    { id: 'hm:recruit', label: 'Recrutar cidadãos', hint: 'Custo 60 ouro • +50 levies (consome comida)' },
    { id: 'hm:train', label: 'Treinar tropas', hint: 'Custo 90 ouro • Converte parte em escudeiros/cavaleiros' },
    { id: 'hm:delegate', label: 'Enviar delegação', hint: 'Custo 30 ouro • Mantém comércio • Relações +1 com parceiros' },
    { id: 'back', label: 'Voltar' },
  ]);
}

export function applyHouseMgmt(state: GameState, rng: Rng, action: string): void {
  const player = state.characters[state.playerId];
  const house = state.houses[state.playerHouseId];
  if (house.leaderId !== player.id) {
    pushNarration(state, 'Você não é o líder da Casa.');
    return promptMainMenu(state, rng);
  }

  switch (action) {
    case 'farm': {
      if (house.resources.gold < 120) {
        pushNarration(state, 'Ouro insuficiente.');
        return promptMainMenu(state, rng);
      }
      house.resources.gold -= 120;
      house.economy.farms += 1;
      house.economy.peasants += 40;
      house.prestige = clamp(house.prestige + 1, 1, 100);
      pushNarration(state, 'Você compra novas fazendas e atrai mais camponeses. Produção aumenta. Prestígio +1.');
      return promptMainMenu(state, rng);
    }
    case 'recruit': {
      if (house.resources.gold < 60) {
        pushNarration(state, 'Ouro insuficiente.');
        return promptMainMenu(state, rng);
      }
      house.resources.gold -= 60;
      house.army.levies += 50;
      house.economy.soldiers += 20;
      pushNarration(state, 'Você recruta e arma cidadãos. Levies +50.');
      return promptMainMenu(state, rng);
    }
    case 'train': {
      if (house.resources.gold < 90) {
        pushNarration(state, 'Ouro insuficiente.');
        return promptMainMenu(state, rng);
      }
      house.resources.gold -= 90;
      // conversões simples: parte dos levies vira men-at-arms; parte vira squires; pequena chance de knights
      const toMen = Math.min(house.army.levies, rng.int(12, 22));
      house.army.levies -= toMen;
      house.army.menAtArms += toMen;

      const toSquires = Math.min(house.army.menAtArms, rng.int(6, 14));
      house.army.menAtArms -= toSquires;
      house.army.squires += toSquires;

      const toKnights = Math.min(house.army.squires, rng.int(1, 4));
      house.army.squires -= toKnights;
      house.army.knights += toKnights;

      house.economy.trainingGrounds = clamp(house.economy.trainingGrounds + (rng.chance(0.25) ? 1 : 0), 0, 3);
      pushNarration(state, `Treinamento concluído: +${toMen} homens-de-armas, +${toSquires} escudeiros, +${toKnights} cavaleiros.`);
      return promptMainMenu(state, rng);
    }
    case 'delegate': {
      if (house.resources.gold < 30) {
        pushNarration(state, 'Ouro insuficiente.');
        return promptMainMenu(state, rng);
      }
      house.resources.gold -= 30;
      house.economy.tradeLastDelegationTurn = state.date.absoluteTurn;

      for (const partnerId of house.economy.tradePartners) {
        house.relations[partnerId] = clamp((house.relations[partnerId] ?? 50) + 1, 0, 100);
        // o parceiro também melhora
        const partner = state.houses[partnerId];
        if (partner) partner.relations[house.id] = clamp((partner.relations[house.id] ?? 50) + 1, 0, 100);
      }
      pushNarration(state, 'Delegação enviada. O comércio continua a fluir (e a etiqueta também).');
      return promptMainMenu(state, rng);
    }
  }
}

function promptChronicle(state: GameState, rng: Rng): void {
  const last = state.chronicle.slice(0, 10).map(e => `• [T${e.turn}] ${e.title}`).join('
');
  const scheduled = SCHEDULED_EVENTS
    .filter(e => e.year === state.date.year && e.turn === state.date.turn)
    .map(e => `• (Agendado) ${e.title}`)
    .join('
');

  pushSystem(
    state,
    `Crônicas (últimas 10):
${last || '—'}

Neste turno:
${scheduled || '—'}

Você também pode ver detalhes na aba “Crônicas”.`,
    [{ id: 'back', label: 'Voltar' }]
  );
}

export function advanceTurn(state: GameState, rng: Rng): void {
  if (state.game.over) return;

  // Endgame rígido por tempo: se chegarmos além do limite, encerra.
  if (state.date.year > ENDGAME_BURN_YEAR) {
    return setGameOver(state, 'O mundo mudou além do ponto de retorno. Sua história termina aqui.', false);
  }

  // Eventos "fixos" do fim da era (Gelo & Fogo)
  if (!state.endgame.wallBreached && state.date.year === ENDGAME_WALL_YEAR && state.date.turn === ENDGAME_WALL_TURN) {
    state.endgame.wallBreached = true;
    state.chronicle.unshift({
      turn: state.date.absoluteTurn,
      title: 'A Muralha é Rompida',
      body: 'No extremo Norte, a Muralha ruge — e uma brecha se abre. O frio caminha para o sul.',
      tags: ['norte', 'ameaça', 'white-walkers'],
    });
    pushNarration(state, '❄️ A Muralha é rompida. Os White Walkers avançam — um presságio que engole os reinos.');
  }

  if (!state.endgame.danyArrived && state.date.year === ENDGAME_DANY_YEAR && state.date.turn === ENDGAME_DANY_TURN) {
    ensureDaenerysFaction(state, rng);
    pushNarration(state, '🔥 Rumores se tornam certeza: Daenerys Targaryen chega a Westeros com um exército quase impossível de derrotar.');
    pushNarration(state, '🐉 Seus dragões não aparecem como mecânica — mas, em batalha, contam como **10.000 cavaleiros** cada, além do exército que ela já possui.');
  }

  if (!state.endgame.kingsLandingBurned && state.date.year === ENDGAME_BURN_YEAR && state.date.turn === ENDGAME_BURN_TURN) {
    state.endgame.kingsLandingBurned = true;
    state.chronicle.unshift({
      turn: state.date.absoluteTurn,
      title: 'As Cinzas de Porto Real',
      body: 'Porto Real cai em chamas. A cidade e o reino entram em uma nova era de medo e ruínas.',
      tags: ['porto-real', 'daenerys', 'fim'],
    });
    pushNarration(state, '🔥 Porto Real queima. O mundo entra em ruínas — e a sua crônica se aproxima do fim.');

    // Se o jogador ainda não alcançou uma condição de "vitória" (casar/derrotar), é game over por tempo.
    if (!state.game.victory) {
      return setGameOver(state, 'Porto Real ardeu e a era chegou ao seu ponto final. Sem uma virada impossível, a história termina.', false);
    }
    return;
  }

  // 1) Processa eventos agendados
  for (const e of SCHEDULED_EVENTS) {
    if (e.year === state.date.year && e.turn === state.date.turn) {
      state.chronicle.unshift({ turn: state.date.absoluteTurn, title: e.title, body: e.body, tags: e.tags });
      pushNarration(state, `📜 ${e.title}: ${e.body}`);
    }
  }

  // 2) Economia e consumo
  tickEconomy(state, rng);

  // 3) Idade e mortes por idade (regras do usuário)
  tickAgesAndDeaths(state, rng);

  // 4) Nascimentos (simulação simples)
  tickBirths(state, rng);

  // 4.5) Torneios (geração + expiração)
  tickTournaments(state, rng);

  // 5) Pressão do Banco de Ferro
  tickIronBank(state, rng);

  // 6) Avança data
  state.date.absoluteTurn += 1;
  state.date.turn += 1;
  if (state.date.turn > 20) {
    state.date.turn = 1;
    state.date.year += 1;
  }

  pushNarration(state, `⏳ O tempo passa. Agora é Ano ${state.date.year} DC, Turno ${state.date.turn}/20.`);

  // 7) Menu
  promptMainMenu(state, rng);
}

function tickEconomy(state: GameState, rng: Rng): void {
  const house = state.houses[state.playerHouseId];
  const econ = house.economy;
  const army = house.army;

  // produção de comida: camponeses + fazendas
  const foodProd = Math.round(econ.peasants * 0.18 + econ.farms * 80);
  // consumo: população + tropas (upkeep)
  const pop = econ.peasants + econ.soldiers;
  const foodCons = Math.round(pop * 0.10 + (army.levies * 0.30) + (army.menAtArms * 0.55) + (army.squires * 0.75) + (army.knights * 1.10));

  house.resources.food += foodProd - foodCons;

  // renda: impostos + comércio (se delegação ok)
  const baseGold = Math.round(pop * 0.06);
  let tradeGold = 0;
  const turnsSinceDel = state.date.absoluteTurn - econ.tradeLastDelegationTurn;
  if (turnsSinceDel <= 5 && econ.tradePartners.length > 0) {
    tradeGold = 30 + econ.tradePartners.length * 12;
  } else if (econ.tradePartners.length > 0 && turnsSinceDel > 5) {
    // deteriora relações lentamente por negligência
    for (const partnerId of econ.tradePartners) {
      house.relations[partnerId] = clamp((house.relations[partnerId] ?? 50) - 1, 0, 100);
    }
  }

  house.resources.gold += baseGold + tradeGold;

  // se comida cair abaixo de 0, fome -> prestígio cai e população sofre
  if (house.resources.food < 0) {
    const deficit = Math.abs(house.resources.food);
    const lossPeasants = Math.min(econ.peasants, Math.ceil(deficit / 40));
    econ.peasants -= lossPeasants;
    house.resources.food = 0;
    house.prestige = clamp(house.prestige - 2, 1, 100);
    pushNarration(state, `⚠️ Fome em suas terras. Você perde ${lossPeasants} camponeses. Prestígio -2.`);
  }
}

function deathChanceByAge(age: number): number {
  // regra pedida: 55:5%, 60:10%, 65:15%, 70:20%...
  if (age < 55) return 0;
  const step = Math.floor((age - 55) / 5) + 1; // 55..59 =>1, 60..64=>2...
  return clamp(step * 0.05, 0.05, 0.95);
}

function tickAgesAndDeaths(state: GameState, rng: Rng): void {
  // 1 turno = 1/20 ano
  const delta = 1 / 20;

  for (const c of Object.values(state.characters)) {
    if (!c.alive) continue;
    c.ageYears = Math.round((c.ageYears + delta) * 100) / 100;

    const p = deathChanceByAge(c.ageYears);
    if (p > 0 && rng.chance(p)) {
      c.alive = false;
      c.maritalStatus = c.maritalStatus === 'married' ? 'widowed' : c.maritalStatus;
      pushNarration(state, `⚰️ ${c.name} morre de causas naturais aos ${Math.floor(c.ageYears)} anos.`);

      // viúvo(a) volta ao sobrenome de nascimento conforme regra
      if (c.spouseId) {
        const spouse = state.characters[c.spouseId];
        if (spouse && spouse.alive) {
          spouse.maritalStatus = 'widowed';
          if (spouse.gender === 'F' && spouse.birthHouseId !== spouse.currentHouseId) {
            spouse.currentHouseId = spouse.birthHouseId;
            spouse.keepsBirthName = true;
          }
        }
      }

      // Se era líder de casa, resolve sucessão
      for (const h of Object.values(state.houses)) {
        if (h.leaderId === c.id) {
          const succ = computeSuccessor(state, rng, h.id);
          if (succ) {
            h.leaderId = succ.id;
            succ.title = titleForHouse(h.id, succ.gender);
            pushNarration(state, `👑 ${succ.name} torna-se líder de ${h.name}.`);
          }
        }
      }

      // Se o jogador morreu:
      if (c.id === state.playerId) {
        handlePlayerDeath(state, rng, 'Morte por idade');
        return;
      }
    }
  }
}

function computeSuccessor(state: GameState, rng: Rng, houseId: string): Character | null {
  const house = state.houses[houseId];
  const currentLeader = state.characters[house.leaderId];

  // coletar candidatos que pertencem à casa (sobrenome atual == houseId) e estão vivos
  const candidates = Object.values(state.characters).filter(c => c.alive && c.currentHouseId === houseId);

  // helper: filhos do líder (ordenados por idade desc), sexo
  const children = candidates.filter(c => c.fatherId === currentLeader.id || c.motherId === currentLeader.id);

  const sons = children.filter(c => c.gender === 'M').sort((a,b)=> b.ageYears - a.ageYears);
  const daughters = children.filter(c => c.gender === 'F').sort((a,b)=> b.ageYears - a.ageYears);

  const siblings = candidates.filter(c => c.fatherId && currentLeader.fatherId && c.fatherId === currentLeader.fatherId && c.id !== currentLeader.id);
  const brothers = siblings.filter(c => c.gender === 'M').sort((a,b)=> b.ageYears - a.ageYears);
  const sisters = siblings.filter(c => c.gender === 'F').sort((a,b)=> b.ageYears - a.ageYears);

  // tios/primos (aproximação): qualquer membro vivo da casa mais velho que 18, excluindo filhos/irmãos
  const extended = candidates
    .filter(c => c.id !== currentLeader.id && !children.includes(c) && !siblings.includes(c))
    .sort((a,b)=> b.ageYears - a.ageYears);

  const unclesCousinsMale = extended.filter(c => c.gender === 'M');
  const unclesCousinsFemale = extended.filter(c => c.gender === 'F');

  // regra do usuário (prioridade): filhos homens, irmãos homens, tios homens, primos homens, filhas, irmãs, tias, primas
  const order = [...sons, ...brothers, ...unclesCousinsMale, ...daughters, ...sisters, ...unclesCousinsFemale];

  // filtrar mulheres que “não podem” herdar por estarem casadas com outro sobrenome (nesta função, currentHouseId já garante)
  const chosen = order[0] ?? null;
  return chosen;
}

function tickBirths(state: GameState, rng: Rng): void {
  // Para simplificar: a cada turno, alguns casais nobres têm chance baixa de ter filho.
  // O jogador pode ampliar isso futuramente via eventos de relacionamento (beijos/relações).
  const couples: Array<{father: Character, mother: Character, houseId: string}> = [];

  for (const c of Object.values(state.characters)) {
    if (!c.alive || c.maritalStatus !== 'married' || !c.spouseId) continue;
    const spouse = state.characters[c.spouseId];
    if (!spouse || !spouse.alive || spouse.maritalStatus !== 'married') continue;
    // captura uma vez (pai/mãe)
    if (c.gender === 'M' && spouse.gender === 'F') {
      couples.push({ father: c, mother: spouse, houseId: c.currentHouseId });
    }
  }

  for (const pair of couples) {
    // faixa fértil simplificada
    if (pair.mother.fertility === 'sterile') continue;
    if (pair.mother.ageYears < 16 || pair.mother.ageYears > 40) continue;
    if (pair.father.ageYears < 16 || pair.father.ageYears > 60) continue;

    // chance por turno ~1.5% (aprox. 30% a.a. com 20 turnos)
    const p = 0.015;
    if (rng.chance(p)) {
      const gender: Gender = rng.chance(0.55) ? 'M' : 'F';
      
const baby = { ...spawnChild(state, rng, pair.father, pair.mother, gender) };

const isPlayerParent = pair.father.id === state.playerId || pair.mother.id === state.playerId;
if (isPlayerParent) {
  // Nomear imediatamente (fila de nomes)
  baby.name = '— sem nome —';
  state.ui.pendingNameQueue = state.ui.pendingNameQueue ?? [];
  state.ui.pendingNameQueue.push(baby.id);
  pushNarration(state, `👶 Você teve um(a) bebê! Abra a janela de nomeação para escolher o primeiro nome agora.`);
} else {
  pushNarration(state, `👶 Nasce ${baby.name} na ${state.houses[pair.houseId].name}.`);
}

state.chronicle.unshift({
  turn: state.date.absoluteTurn,
  title: 'Nascimento nobre',
  body: `${baby.name} nasce na ${state.houses[pair.houseId].name}.`,
  tags: ['nascimento']
});
    }
  }
}


function prestigeToTournamentSize(prestige: number): TournamentSize {
  if (prestige < 45) return 'menor';
  if (prestige < 75) return 'medio';
  return 'importante';
}

function categoriesForSize(size: TournamentSize): RenownTier[] {
  // 3 tipos conforme pedido: menor (fraco->intermediário), médio (2º fraco->2º forte), importante (intermediário->mais forte)
  if (size === 'menor') return ['comum', 'forte', 'reconhecido'];
  if (size === 'medio') return ['forte', 'reconhecido', 'imponente'];
  return ['reconhecido', 'imponente', 'renomado'];
}

function randomTournamentReason(rng: Rng): TournamentReason {
  const pool: TournamentReason[] = ['maioridade', 'casamento', 'vitoria', 'colheita', 'outro'];
  return pool[rng.int(0, pool.length - 1)];
}

function tickTournaments(state: GameState, rng: Rng): void {
  // expira torneios antigos (após ~6 turnos)
  for (const t of state.tournaments) {
    if (t.status === 'anunciado' && (state.date.absoluteTurn - t.announcedTurn) > 6) {
      t.status = 'encerrado';
    }
  }

  // chance moderada de surgir 0-1 torneio por turno no reino (simplificado)
  if (rng.chance(0.10)) {
    const hostPool = Object.values(state.houses);
    const host = hostPool[rng.int(0, hostPool.length - 1)];
    const size = prestigeToTournamentSize(host.prestige);
    const reason = randomTournamentReason(rng);
    const t: Tournament = {
      id: uid('t'),
      hostHouseId: host.id,
      locationId: host.seatLocationId,
      size,
      reason,
      announcedTurn: state.date.absoluteTurn,
      status: 'anunciado',
      categories: categoriesForSize(size),
    };
    state.tournaments.unshift(t);

    const title = `Torneio ${size === 'menor' ? 'menor' : size === 'medio' ? 'mediano' : 'importante'} anunciado`;
    const body = `${state.houses[host.id].name} anuncia um torneio em ${state.locations[t.locationId]?.name ?? 'seus domínios'} (${t.reason}).`;
    state.chronicle.unshift({ turn: state.date.absoluteTurn, title, body, tags: ['torneio'] });
    pushNarration(state, `🏇 ${body}`);
  }
}

function spawnChild(state: GameState, rng: Rng, father: Character, mother: Character, gender: Gender): Character {
  const id = uid('c');
  const name = genFirstName(rng, gender);
  const houseId = father.currentHouseId;
  const locationId = father.locationId;

  const child: Character = {
    id,
    name,
    gender,
    ageYears: 0,
    alive: true,

    birthHouseId: houseId,
    currentHouseId: houseId,

    fatherId: father.id,
    motherId: mother.id,

    maritalStatus: 'single',
    keepsBirthName: false,
    locationId,

    martial: rng.int(0, 5),
    charm: rng.int(0, 5),
    beauty: rng.int(0, 5),
    renownTier: 'comum',
    fertility: rng.chance(0.05) ? 'sterile' : 'fertile',
    wellLiked: rng.int(10, 40),
    personalPrestige: 0,

    knownToPlayer: false,
    relationshipToPlayer: 0,
  };

  state.characters[id] = child;
  return child;
}

function tickIronBank(state: GameState, rng: Rng): void {
  const debt = state.ironBankDebt;
  if (!debt) return;

  if (state.date.absoluteTurn >= debt.nextPaymentTurn) {
    const house = state.houses[state.playerHouseId];
    if (house.resources.gold >= debt.minimumPayment) {
      house.resources.gold -= debt.minimumPayment;
      debt.principal = Math.max(0, Math.round(debt.principal - debt.minimumPayment * 0.60)); // parte amortiza
      debt.nextPaymentTurn += 20;
      debt.missedPayments = Math.max(0, debt.missedPayments - 1);
      pushNarration(state, `🏦 Você paga ${debt.minimumPayment} ouro ao Banco de Ferro. A dívida diminui (principal agora ${debt.principal}).`);
      if (debt.principal <= 0) {
        state.ironBankDebt = null;
        house.prestige = clamp(house.prestige + 1, 1, 100);
        pushNarration(state, '🏦 Dívida quitada. Sua Casa respira. Prestígio +1.');
      }
    } else {
      debt.missedPayments += 1;
      debt.nextPaymentTurn += 10; // pressão acelera
      pushNarration(state, `🏦 Você não consegue pagar o Banco de Ferro. A pressão aumenta (atrasos: ${debt.missedPayments}).`);

      // intervenção se muito grave
      if (debt.missedPayments >= 3) {
        const house = state.houses[state.playerHouseId];
        house.prestige = clamp(house.prestige - 5, 1, 100);
        house.resources.gold = Math.max(0, house.resources.gold - 120);
        pushNarration(state, '⚔️ Braavos impõe sanções e “cobradores” — sua economia sofre e sua honra despenca. Prestígio -5.');
      }
      if (debt.missedPayments >= 5) {
        pushNarration(state, '🩸 Intervenção do Banco de Ferro: mercenários e credores exigem rendas e portos. Você corre risco de ruína total.');
      }
    }
  }

  // juros acumulam 1x ao ano (a cada 20 turnos, no pagamento)
}

export function applyIronBank(state: GameState, rng: Rng, cmd: string): void {
  const house = state.houses[state.playerHouseId];
  if (cmd.startsWith('loan:')) {
    const amount = parseInt(cmd.split(':')[1], 10);
    house.resources.gold += amount;
    house.prestige = clamp(house.prestige - Math.ceil(amount / 350), 1, 100);
    state.ironBankDebt = {
      principal: amount,
      interestRateYear: 0.12,
      nextPaymentTurn: state.date.absoluteTurn + 20,
      minimumPayment: Math.round(amount * 0.18),
      missedPayments: 0,
    };
    pushNarration(state, `🏦 Empréstimo aprovado: +${amount} ouro. Próximo pagamento em 20 turnos.`);
    return promptMainMenu(state, rng);
  }
  if (cmd === 'paymin') {
    const debt = state.ironBankDebt;
    if (!debt) return promptMainMenu(state, rng);
    if (house.resources.gold < debt.minimumPayment) {
      pushNarration(state, 'Ouro insuficiente para pagar o mínimo.');
      return promptMainMenu(state, rng);
    }
    house.resources.gold -= debt.minimumPayment;
    debt.principal = Math.max(0, Math.round(debt.principal - debt.minimumPayment * 0.60));
    debt.nextPaymentTurn += 20;
    debt.missedPayments = Math.max(0, debt.missedPayments - 1);
    pushNarration(state, `🏦 Pagamento mínimo efetuado. Principal agora ${debt.principal}.`);
    if (debt.principal <= 0) {
      state.ironBankDebt = null;
      house.prestige = clamp(house.prestige + 1, 1, 100);
      pushNarration(state, '🏦 Dívida quitada. Prestígio +1.');
    }
    return promptMainMenu(state, rng);
  }
  if (cmd === 'payall') {
    const debt = state.ironBankDebt;
    if (!debt) return promptMainMenu(state, rng);
    const pay = debt.principal;
    if (house.resources.gold < pay) {
      pushNarration(state, 'Ouro insuficiente para quitar tudo.');
      return promptMainMenu(state, rng);
    }
    house.resources.gold -= pay;
    state.ironBankDebt = null;
    house.prestige = clamp(house.prestige + 1, 1, 100);
    pushNarration(state, `🏦 Você quita ${pay} ouro. Dívida encerrada. Prestígio +1.`);
    return promptMainMenu(state, rng);
  }
}

export function handlePlayerDeath(state: GameState, rng: Rng, reason: string): void {
  const houseId = state.playerHouseId;
  const next = computeSuccessor(state, rng, houseId);
  if (next) {
    state.playerId = next.id;
    state.playerHouseId = next.currentHouseId;
    pushNarration(state, `🕯️ Controle transferido para ${next.name} (${state.houses[state.playerHouseId].name}). Motivo: ${reason}.`);
  } else {
    setGameOver(state, `Sua linhagem se apaga. Não há herdeiro elegível — fim de jogo. (${reason})`, false);
  }
}



export function applyLocalAction(state: GameState, rng: Rng, action: 'talk'|'flowers'|'drink'|'hunt', targetId: string): void {
  const player = state.characters[state.playerId];
  const target = state.characters[targetId];
  if (!target || !target.alive) return;

  if (target.locationId !== player.locationId) {
    pushNarration(state, 'Essa pessoa não está no mesmo local que você.');
    return;
  }

  // ações melhoram relação pessoal e, suavemente, relações entre casas
  const delta = action === 'flowers' ? 6 : action === 'talk' ? 4 : 5;
  target.knownToPlayer = true;
  target.relationshipToPlayer = clamp(target.relationshipToPlayer + delta + rng.int(-2, 2), 0, 100);

  const ph = state.houses[state.playerHouseId];
  const th = state.houses[target.currentHouseId];
  if (th && th.id !== ph.id) {
    ph.relations[th.id] = clamp((ph.relations[th.id] ?? 50) + 1, 0, 100);
  }

  const label = action === 'flowers' ? 'flores' : action === 'drink' ? 'beber' : action === 'hunt' ? 'caçar' : 'conversar';
  pushNpc(state, target.name, `Você decide ${label}. A relação com você agora é ${target.relationshipToPlayer}/100.`);
  promptMainMenu(state, rng);
}

export function applyTournamentAction(state: GameState, rng: Rng, cmd: string): void {
  const [action, tid] = cmd.split(':');

  const player = state.characters[state.playerId];
  if (action !== 'join') return;

  // Participar
  if (player.injuredUntilTurn && player.injuredUntilTurn > state.date.absoluteTurn) {
    pushNarration(state, 'Você está ferido(a) e não pode competir neste turno.');
    return;
  }
  if (player.locationId !== t.locationId) {
    pushNarration(state, 'Você precisa estar no local do torneio para competir.');
    return;
  }
  if (!t.categories.includes(player.renownTier)) {
    pushNarration(state, `Você não se enquadra nas categorias deste torneio. Sua categoria atual: ${player.renownTier}.`);
    return;
  }

  // Resultado conforme probabilidades pedidas: morrer 10%, derrota 30%, ferido 20%, vitória 40%
  const roll = rng.float(); // 0..1
  if (roll < 0.10) {
    pushNarration(state, '☠️ Você cai mortalmente ferido(a) nas justas.');
    player.alive = false;
    handlePlayerDeath(state, rng, 'Morte em torneio');
    return;
  }
  if (roll < 0.40) {
    // derrota comum
    player.personalPrestige = clamp(player.personalPrestige - 2, 0, 100);
    pushNarration(state, `🥀 Você perde a justa na categoria ${player.renownTier}. Prestígio pessoal -2.`);
    promptMainMenu(state, rng);
    return;
  }
  if (roll < 0.60) {
    // ferido e perde prestígio
    player.personalPrestige = clamp(player.personalPrestige - 5, 0, 100);
    house.prestige = clamp(house.prestige - 1, 1, 100);
    player.injuredUntilTurn = state.date.absoluteTurn + 2;
    pushNarration(state, `🩸 Você se fere gravemente e perde a luta. Prestígio pessoal -5, prestígio da Casa -1. (Ferido por 2 turnos)`);
    promptMainMenu(state, rng);
    return;
  }
  // vitória
  player.personalPrestige = clamp(player.personalPrestige + 10, 0, 100);
  house.prestige = clamp(house.prestige + 2, 1, 100);
  house.resources.gold += 60;
  pushNarration(state, `🏆 Você vence as justas (${player.renownTier})! +10 prestígio pessoal, +2 prestígio da Casa, +60 ouro.`);
  // chance pequena de casamento com prêmio (apenas sinalizado)
  if (rng.chance(0.18)) {
    pushNarration(state, '💍 Rumores correm: uma família observa você como possível pretendente(a) após a vitória.');
  }
  promptMainMenu(state, rng);
}

