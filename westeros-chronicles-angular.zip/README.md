# GitHub Pages (Angular)

Este pacote já vem com:
- `westeros-chronicles-angular.zip` na raiz do repositório
- Workflow em `.github/workflows/deploy-angular-pages.yml` pronto para publicar no GitHub Pages.

## Como usar
1. Suba o conteúdo deste zip como um repositório no GitHub (branch `main`).
2. Em **Settings → Pages**, selecione **Source: GitHub Actions**.
3. Faça um push na `main` e aguarde o deploy.

Se você quiser que `npm ci` seja usado sempre, gere e inclua um `package-lock.json` dentro do projeto Angular.
