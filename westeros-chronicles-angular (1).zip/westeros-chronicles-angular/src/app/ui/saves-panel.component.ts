import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GameState } from '../core/models';
import { SaveService } from '../core/engine/save.service';

@Component({
  selector: 'app-saves-panel',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './saves-panel.component.html',
  styleUrl: './saves-panel.component.css',
})
export class SavesPanelComponent {
  @Input({ required: true }) state!: GameState;
  @Output() loadState = new EventEmitter<GameState>();

  constructor(public saves: SaveService) {}

  private normSlot(slot: number): 1|2|3 {
    return (slot === 1 || slot === 2 || slot === 3) ? (slot as 1|2|3) : 1;
  }

  slotInfo(slot: number): {label: string, updatedAt?: number} {
    const file = this.saves.loadFile();
    const k = this.normSlot(slot);
    const s = file.slots[k];
    return s ? { label: `Slot ${k}`, updatedAt: s.updatedAt } : { label: `Slot ${k}` };
  }

  save(slot: number): void {
    this.saves.save(this.normSlot(slot), this.state);
  }

  load(slot: number): void {
    const st = this.saves.load(this.normSlot(slot));
    if (st) this.loadState.emit(st);
  }

  clear(slot: number): void {
    this.saves.clear(this.normSlot(slot));
  }

  fmt(ts?: number): string {
    if (!ts) return '—';
    return new Date(ts).toLocaleString('pt-BR');
  }
}
