import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GameState } from '../core/models';

@Component({
  selector: 'app-character-panel',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './character-panel.component.html',
  styleUrl: './character-panel.component.css',
})
export class CharacterPanelComponent {
  @Input({ required: true }) state!: GameState;
}
