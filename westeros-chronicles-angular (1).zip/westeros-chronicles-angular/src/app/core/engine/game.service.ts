import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

import { GameState, Gender, HouseState, Character } from '../models';
import { REGIONS, LOCATIONS, TRAVEL_GRAPH } from '../data/regions';
import { HOUSES } from '../data/houses';
import { buildInitialState, applyChoice, applyTravel, applyDiplomacy, applyDiplomacyChoice, applyDaenerysAction, applyTraining, applyHouseMgmt, applyIronBank, applyLocalAction, applyTournamentAction, promptMainMenu } from './sim';
import { Rng } from './rng';
import { uid } from './utils';

function toMap<T extends {id: string}>(arr: T[]): Record<string, T> {
  return arr.reduce((acc, x) => { acc[x.id] = x; return acc; }, {} as Record<string, T>);
}

@Injectable({ providedIn: 'root' })
export class GameService {
  private rng = new Rng(Date.now() >>> 0);
  private state$ = new BehaviorSubject<GameState | null>(null);

  readonly vm$ = this.state$.asObservable();

  constructor() {}

  newGame(playerHouseId: string, gender: Gender): void {
    const housesBase = this.buildBaseHouses();
    const charactersBase: Record<string, Character> = {};

    const state = buildInitialState(this.rng.getSeed(), { playerHouseId, gender }, {
      locations: toMap(LOCATIONS),
      regions: toMap(REGIONS),
      travelGraph: TRAVEL_GRAPH,
      houses: housesBase,
      characters: charactersBase,
    });

    this.state$.next(state);
  }

  setState(state: GameState): void {
    // migração leve (caso carregue saves antigos)
    (state as any).game = (state as any).game ?? { over: false, victory: false, reason: '' };
    (state as any).endgame = (state as any).endgame ?? { wallBreached: false, danyArrived: false, danyRelation: 0, kingsLandingBurned: false };
    (state as any).tournaments = (state as any).tournaments ?? [];
    state.ui = (state as any).ui ?? { activeTab: 'chat', showSetup: false, pendingNameQueue: [] };
    (state.ui as any).pendingNameQueue = (state.ui as any).pendingNameQueue ?? [];
    for (const c of Object.values(state.characters)) {
      (c as any).personalPrestige = (c as any).personalPrestige ?? 0;
    }
    for (const h of Object.values(state.houses)) {
      (h as any).army.dragons = (h as any).army.dragons ?? 0;
    }

    // reseta rng a partir do "tempo" (mantém pseudo-determinismo)
    this.rng.setSeed(state.date.absoluteTurn * 2654435761 >>> 0);
    this.state$.next(state);
  }

  getState(): GameState {
    const s = this.state$.value;
    if (!s) throw new Error('Estado não inicializado.');
    return s;
  }

  choose(choiceId: string): void {
    const s = this.getState();

    if (choiceId === 'reset') {
      this.state$.next(null);
      return;
    }

    if (s.game?.over && !['saves'].includes(choiceId)) {
      // Em game over, só permitimos abrir a aba de saves (e reset via botão).
      return;
    }
    // comandos especiais embutidos em choiceId
    if (choiceId === 'back') {
      // volta ao menu principal via sim.ts (recriando prompt)
      // truque: chama applyChoice com end_turn? não. Melhor: adiciona mensagem e recria menu.
      // Aqui só reemitimos o menu principal com uma pequena escolha.
      // Para evitar circular import, usamos applyChoice em "no-op": reabrir menu pelo workflow normal
      // -> adicionamos um "sistema" e acionamos a próxima mensagem escolhendo "chronicle"? Não.
      // Simples: cria um prompt atual com as mesmas opções novamente chamando applyChoice em 'chronicle' não.
      // Então: vamos chamar um “choice” interno: 'chronicle' não. Melhor: usamos applyChoice? não tem.
      // Solução: chamamos applyChoice com um id inválido não faz nada. Então, aqui a gente reseta o last choices e injeta um novo menu.
      promptMainMenu(s, this.rng);
      return this.state$.next({ ...s });
    }

    // travel: go:location
    if (choiceId.startsWith('go:')) {
      const to = choiceId.split(':')[1];
      applyTravel(s, this.rng, to);
      return this.state$.next({ ...s });
    }

    // diplomacy
    if (choiceId.startsWith('dip:')) {
      const action = choiceId.split(':')[1];
      applyDiplomacy(s, this.rng, action);
      return this.state$.next({ ...s });
    }

    if (choiceId.startsWith('dany:')) {
      applyDaenerysAction(s, this.rng, choiceId.split(':')[1]);
      return this.state$.next({ ...s });
    }
    if (choiceId.startsWith('talk:')) {
      applyDiplomacyChoice(s, this.rng, 'talk', choiceId.split(':')[1]);
      return this.state$.next({ ...s });
    }
    if (choiceId.startsWith('gift:')) {
      applyDiplomacyChoice(s, this.rng, 'gift', choiceId.split(':')[1]);
      return this.state$.next({ ...s });
    }
    if (choiceId.startsWith('aud:')) {
      applyDiplomacyChoice(s, this.rng, 'aud', choiceId.split(':')[1]);
      return this.state$.next({ ...s });
    }
    if (choiceId.startsWith('mar:')) {
      applyDiplomacyChoice(s, this.rng, 'mar', choiceId.split(':')[1]);
      return this.state$.next({ ...s });
    }
    if (choiceId.startsWith('ib:loan:')) {
      const amt = choiceId.split(':')[2];
      applyIronBank(s, this.rng, `loan:${amt}`);
      return this.state$.next({ ...s });
    }
    if (choiceId === 'ib:paymin') {
      applyIronBank(s, this.rng, 'paymin');
      return this.state$.next({ ...s });
    }
    if (choiceId === 'ib:payall') {
      applyIronBank(s, this.rng, 'payall');
      return this.state$.next({ ...s });
    }

    // training
    if (choiceId.startsWith('tr:')) {
      applyTraining(s, this.rng, choiceId.split(':')[1]);
      return this.state$.next({ ...s });
    }

    // house mgmt
    if (choiceId.startsWith('hm:')) {
      applyHouseMgmt(s, this.rng, choiceId.split(':')[1]);
      return this.state$.next({ ...s });
    }

    // local interactions (personagens no local)
    if (choiceId.startsWith('loc:')) {
      const [, action, targetId] = choiceId.split(':');
      applyLocalAction(s, this.rng, action as any, targetId);
      return this.state$.next({ ...s });
    }

    // tournaments
    if (choiceId.startsWith('tour:')) {
      const cmd = choiceId.substring('tour:'.length);
      applyTournamentAction(s, this.rng, cmd);
      return this.state$.next({ ...s });
    }

    // generic
    applyChoice(s, this.rng, choiceId);
    this.state$.next({ ...s });
  }


  nameChild(childId: string, firstName: string): void {
  const s = this.getState();
  const q = (s.ui as any).pendingNameQueue as string[] | undefined;
  const child = s.characters[childId];
  if (!child) return;
  const clean = (firstName || '').trim();
  if (!clean) return;

  child.name = clean;
  // remove from queue
  if (q) {
    const idx = q.indexOf(childId);
    if (idx >= 0) q.splice(idx, 1);
  }

  s.chat.push({
    id: uid('m'),
    speaker: 'narrador' as any,
    text: `👶 O bebê recebe o nome de ${clean}.`,
    tsTurn: s.date.absoluteTurn,
  });
  s.chronicle.unshift({
    turn: s.date.absoluteTurn,
    title: 'Nomeado',
    body: `${clean} recebe seu nome.`,
    tags: ['nascimento'],
  });

  this.state$.next({ ...s });
}

  nextPendingBabyId(): string | null {
  const s = this.getState();
  const q = (s.ui as any).pendingNameQueue as string[] | undefined;
  return q && q.length ? q[0] : null;
}

  private buildBaseHouses(): Record<string, HouseState> {

    const map: Record<string, HouseState> = {};
    for (const h of HOUSES) {
      map[h.id] = {
        ...h,
        prestige: h.prestigeBase,
        relations: {},
        leaderId: '',
        economy: {
          peasants: 0,
          soldiers: 0,
          farms: 0,
          trainingGrounds: 0,
          walls: 0,
          tradeLastDelegationTurn: 0,
          tradePartners: [],
        },
        resources: { gold: 0, food: 0 },
        army: { levies: 0, menAtArms: 0, squires: 0, knights: 0, dragons: 0, stationedRatio: 0.7 },
      };
    }
    return map;
  }
}
