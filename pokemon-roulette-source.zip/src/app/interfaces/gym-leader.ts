export interface GymLeader{
  name: string;
  sprite: string | string[];
  quotes: string[]
}