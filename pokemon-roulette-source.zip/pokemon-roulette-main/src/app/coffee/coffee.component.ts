import { Component } from '@angular/core';
import { NgIconsModule } from '@ng-icons/core';
import { MainGameButtonComponent } from "../main-game-button/main-game-button.component";
import { CommonModule } from '@angular/common';
import { TranslatePipe } from '@ngx-translate/core';
import { ImgFallbackDirective } from '../shared/img-fallback.directive';
import { CreditsButtonComponent } from "../main-game/credits-button/credits-button.component";

@Component({
  selector: 'app-coffee',
  imports: [
    ImgFallbackDirective,
    CommonModule,
    NgIconsModule,
    MainGameButtonComponent,
    TranslatePipe,
    CreditsButtonComponent
],
  templateUrl: './coffee.component.html',
  styleUrl: './coffee.component.css'
})
export class CoffeeComponent {

  readonly pixKey = 'f1f43bfc-b355-4102-b530-256a03241385';
  pixCodeCopied = false;

  copyPixCode(): void {
    navigator.clipboard.writeText(this.pixKey).then(() => {
      this.pixCodeCopied = true;
      setTimeout(() => (this.pixCodeCopied = false), 2000);
    }).catch((err) => {
      console.error('Could not copy PIX key: ', err);
    });
  }

}

}
