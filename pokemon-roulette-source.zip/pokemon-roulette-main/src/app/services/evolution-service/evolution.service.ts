import { Injectable } from '@angular/core';
import { PokemonItem } from '../../interfaces/pokemon-item';
import { evolutionChain } from './evolution-chain';
import { PokemonService } from '../pokemon-service/pokemon.service';

@Injectable({
  providedIn: 'root'
})
export class EvolutionService {

  constructor(private pokemonService: PokemonService) {
    this.nationalDexPokemon = this.pokemonService.getAllPokemon();
  }

  evolutionChain = evolutionChain;
  nationalDexPokemon: PokemonItem[];

  /**
   * Hisui isn't a selectable "region/generation" in this game, so we allow
   * Hisuian FORM evolutions as an exception when the base Pokémon is non-regional.
   *
   * (In this project, Hisuian forms typically use PokeAPI form IDs 10229..10244.)
   */
  private isHisuianFormId(id: number): boolean {
    return id >= 10229 && id <= 10244;
  }

  /**
   * FIX:
   * Some Pokémon exist in evolutionChain with an EMPTY array (e.g., 211:[]).
   * In JS/TS, [] is truthy, so the UI thought they could evolve and could freeze
   * when there were 0 valid options.
   */
  canEvolve(pokemon: PokemonItem): boolean {
    return this.getEvolutions(pokemon).length > 0;
  }

  /**
   * Rules:
   * - If the base Pokémon is a REGIONAL form (has basePokemonId), it only evolves
   *   through its own chain (as defined in evolutionChain).
   * - If the base Pokémon is the ORIGINAL form (no basePokemonId), it evolves only
   *   into NON-regional evolutions (no basePokemonId),
   *   EXCEPT: allow Hisuian FORM evolutions.
   */
  getEvolutions(pokemon: PokemonItem): PokemonItem[] {
    const chain = this.evolutionChain[pokemon.pokemonId];
    if (!chain || chain.length === 0) return [];

    const candidates: PokemonItem[] = chain
      .map((evolutionId) => this.pokemonService.getPokemonById(evolutionId))
      .filter((p): p is PokemonItem => !!p);

    // Non-regional base: remove regional-form targets, but keep Hisui forms.
    if (!pokemon.basePokemonId) {
      return candidates.filter((evo) => !evo.basePokemonId || this.isHisuianFormId(evo.pokemonId));
    }

    // Regional base: keep whatever the chain defines.
    return candidates;
  }
}
