export type EventSource =
  | 'battle-trainer'
  | 'gym-battle'
  | 'visit-daycare'
  | 'team-rocket-encounter'
  | 'snorlax-encounter'
  | 'battle-rival'
  | 'rare-candy';