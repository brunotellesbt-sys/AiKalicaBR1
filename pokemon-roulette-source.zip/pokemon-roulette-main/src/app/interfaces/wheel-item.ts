export interface WheelItem {
  text: string,
  fillStyle: string,
  weight: number;
}