export interface Badge{
  name: string;
  sprite: string;
}