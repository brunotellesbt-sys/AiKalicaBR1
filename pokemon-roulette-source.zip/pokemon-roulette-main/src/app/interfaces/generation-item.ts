import { WheelItem } from "./wheel-item";

export interface GenerationItem extends WheelItem {
  region: string;
  id: number;
}