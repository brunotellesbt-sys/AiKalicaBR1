import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GameState } from '../core/models';
import { SaveService } from '../core/engine/save.service';

@Component({
  selector: 'app-saves-panel',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './saves-panel.component.html',
  styleUrl: './saves-panel.component.css',
})
export class SavesPanelComponent {
  @Input({ required: true }) state!: GameState;
  @Output() loadState = new EventEmitter<GameState>();

  constructor(public saves: SaveService) {}

  slotInfo(slot: 1|2|3): {label: string, updatedAt?: number} {
    const file = this.saves.loadFile();
    const s = file.slots[slot];
    return s ? { label: `Slot ${slot}`, updatedAt: s.updatedAt } : { label: `Slot ${slot}` };
  }

  save(slot: 1|2|3): void {
    this.saves.save(slot, this.state);
  }

  load(slot: 1|2|3): void {
    const st = this.saves.load(slot);
    if (st) this.loadState.emit(st);
  }

  clear(slot: 1|2|3): void {
    this.saves.clear(slot);
  }

  fmt(ts?: number): string {
    if (!ts) return '—';
    return new Date(ts).toLocaleString('pt-BR');
  }
}
